// Auto-generated. Do not edit!

// (in-package app_manager.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class StatusCodes {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
    }
    else {
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type StatusCodes
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type StatusCodes
    let len;
    let data = new StatusCodes(null);
    return data;
  }

  static getMessageSize(object) {
    return 0;
  }

  static datatype() {
    // Returns string type for a message object
    return 'app_manager/StatusCodes';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '5f286aed2b2ab4b227e7b7185bae624d';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Common error codes used with App Manager.
    int32 SUCCESS = 0
    # Request was invalid.
    int32 BAD_REQUEST = 400
    # App is not installed.
    int32 NOT_FOUND = 404
    # App is not running.
    int32 NOT_RUNNING = 430
    # Unknown internal error on the server.
    int32 INTERNAL_ERROR = 500
    # App is installed but failed validation.
    int32 APP_INVALID = 510
    # App manager does not support launching multiple apps simultaneously. Running app must first be stopped.
    int32 MULTIAPP_NOT_SUPPORTED = 511
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new StatusCodes(null);
    return resolved;
    }
};

// Constants for message
StatusCodes.Constants = {
  SUCCESS: 0,
  BAD_REQUEST: 400,
  NOT_FOUND: 404,
  NOT_RUNNING: 430,
  INTERNAL_ERROR: 500,
  APP_INVALID: 510,
  MULTIAPP_NOT_SUPPORTED: 511,
}

module.exports = StatusCodes;
