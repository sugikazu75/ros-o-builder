// Auto-generated. Do not edit!

// (in-package app_manager.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let KeyValue = require('../msg/KeyValue.js');

//-----------------------------------------------------------


//-----------------------------------------------------------

class StartAppRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.name = null;
      this.args = null;
    }
    else {
      if (initObj.hasOwnProperty('name')) {
        this.name = initObj.name
      }
      else {
        this.name = '';
      }
      if (initObj.hasOwnProperty('args')) {
        this.args = initObj.args
      }
      else {
        this.args = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type StartAppRequest
    // Serialize message field [name]
    bufferOffset = _serializer.string(obj.name, buffer, bufferOffset);
    // Serialize message field [args]
    // Serialize the length for message field [args]
    bufferOffset = _serializer.uint32(obj.args.length, buffer, bufferOffset);
    obj.args.forEach((val) => {
      bufferOffset = KeyValue.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type StartAppRequest
    let len;
    let data = new StartAppRequest(null);
    // Deserialize message field [name]
    data.name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [args]
    // Deserialize array length for message field [args]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.args = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.args[i] = KeyValue.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.name);
    object.args.forEach((val) => {
      length += KeyValue.getMessageSize(val);
    });
    return length + 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'app_manager/StartAppRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'fcc3fd7d3a99df15b4752d0b8160ea6c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Name of the app to launch
    string name 
    KeyValue[] args
    
    ================================================================================
    MSG: app_manager/KeyValue
    string key
    string value
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new StartAppRequest(null);
    if (msg.name !== undefined) {
      resolved.name = msg.name;
    }
    else {
      resolved.name = ''
    }

    if (msg.args !== undefined) {
      resolved.args = new Array(msg.args.length);
      for (let i = 0; i < resolved.args.length; ++i) {
        resolved.args[i] = KeyValue.Resolve(msg.args[i]);
      }
    }
    else {
      resolved.args = []
    }

    return resolved;
    }
};

class StartAppResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.started = null;
      this.error_code = null;
      this.message = null;
      this.namespace = null;
    }
    else {
      if (initObj.hasOwnProperty('started')) {
        this.started = initObj.started
      }
      else {
        this.started = false;
      }
      if (initObj.hasOwnProperty('error_code')) {
        this.error_code = initObj.error_code
      }
      else {
        this.error_code = 0;
      }
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
      if (initObj.hasOwnProperty('namespace')) {
        this.namespace = initObj.namespace
      }
      else {
        this.namespace = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type StartAppResponse
    // Serialize message field [started]
    bufferOffset = _serializer.bool(obj.started, buffer, bufferOffset);
    // Serialize message field [error_code]
    bufferOffset = _serializer.int32(obj.error_code, buffer, bufferOffset);
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    // Serialize message field [namespace]
    bufferOffset = _serializer.string(obj.namespace, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type StartAppResponse
    let len;
    let data = new StartAppResponse(null);
    // Deserialize message field [started]
    data.started = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [error_code]
    data.error_code = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [namespace]
    data.namespace = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.message);
    length += _getByteLength(object.namespace);
    return length + 13;
  }

  static datatype() {
    // Returns string type for a service object
    return 'app_manager/StartAppResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '29589baf2876ff624d4cb5688c12265e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # true if app started, false otherwise
    bool started
    # if app did not start, error code for classifying start failure.  See
    # StatusCodes.msg for common codes.
    int32 error_code
    # response message for debugging
    string message
    # Namespace where the app interface can be found
    string namespace  
    
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new StartAppResponse(null);
    if (msg.started !== undefined) {
      resolved.started = msg.started;
    }
    else {
      resolved.started = false
    }

    if (msg.error_code !== undefined) {
      resolved.error_code = msg.error_code;
    }
    else {
      resolved.error_code = 0
    }

    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    if (msg.namespace !== undefined) {
      resolved.namespace = msg.namespace;
    }
    else {
      resolved.namespace = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: StartAppRequest,
  Response: StartAppResponse,
  md5sum() { return '04a4badbc59ce4f974115b26fb1a6711'; },
  datatype() { return 'app_manager/StartApp'; }
};
