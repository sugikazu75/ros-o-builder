
"use strict";

let UninstallApp = require('./UninstallApp.js')
let GetAppDetails = require('./GetAppDetails.js')
let GetInstallationState = require('./GetInstallationState.js')
let InstallApp = require('./InstallApp.js')
let ListApps = require('./ListApps.js')
let StartApp = require('./StartApp.js')
let StopApp = require('./StopApp.js')

module.exports = {
  UninstallApp: UninstallApp,
  GetAppDetails: GetAppDetails,
  GetInstallationState: GetInstallationState,
  InstallApp: InstallApp,
  ListApps: ListApps,
  StartApp: StartApp,
  StopApp: StopApp,
};
