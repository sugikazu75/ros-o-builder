
"use strict";

let DissocTF = require('./DissocTF.js')
let SetDynamicTF = require('./SetDynamicTF.js')
let DeleteTF = require('./DeleteTF.js')
let AssocTF = require('./AssocTF.js')

module.exports = {
  DissocTF: DissocTF,
  SetDynamicTF: SetDynamicTF,
  DeleteTF: DeleteTF,
  AssocTF: AssocTF,
};
