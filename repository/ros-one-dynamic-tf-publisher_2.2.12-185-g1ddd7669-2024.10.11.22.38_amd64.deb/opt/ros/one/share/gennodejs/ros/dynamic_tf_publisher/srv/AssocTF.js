// Auto-generated. Do not edit!

// (in-package dynamic_tf_publisher.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------


//-----------------------------------------------------------

class AssocTFRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.parent_frame = null;
      this.child_frame = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('parent_frame')) {
        this.parent_frame = initObj.parent_frame
      }
      else {
        this.parent_frame = '';
      }
      if (initObj.hasOwnProperty('child_frame')) {
        this.child_frame = initObj.child_frame
      }
      else {
        this.child_frame = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type AssocTFRequest
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [parent_frame]
    bufferOffset = _serializer.string(obj.parent_frame, buffer, bufferOffset);
    // Serialize message field [child_frame]
    bufferOffset = _serializer.string(obj.child_frame, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type AssocTFRequest
    let len;
    let data = new AssocTFRequest(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [parent_frame]
    data.parent_frame = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [child_frame]
    data.child_frame = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += _getByteLength(object.parent_frame);
    length += _getByteLength(object.child_frame);
    return length + 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'dynamic_tf_publisher/AssocTFRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '984a9f3f6741b2b5568909b82fec6355';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    Header  header
    string         parent_frame
    string         child_frame
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new AssocTFRequest(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.parent_frame !== undefined) {
      resolved.parent_frame = msg.parent_frame;
    }
    else {
      resolved.parent_frame = ''
    }

    if (msg.child_frame !== undefined) {
      resolved.child_frame = msg.child_frame;
    }
    else {
      resolved.child_frame = ''
    }

    return resolved;
    }
};

class AssocTFResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
    }
    else {
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type AssocTFResponse
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type AssocTFResponse
    let len;
    let data = new AssocTFResponse(null);
    return data;
  }

  static getMessageSize(object) {
    return 0;
  }

  static datatype() {
    // Returns string type for a service object
    return 'dynamic_tf_publisher/AssocTFResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd41d8cd98f00b204e9800998ecf8427e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new AssocTFResponse(null);
    return resolved;
    }
};

module.exports = {
  Request: AssocTFRequest,
  Response: AssocTFResponse,
  md5sum() { return '984a9f3f6741b2b5568909b82fec6355'; },
  datatype() { return 'dynamic_tf_publisher/AssocTF'; }
};
