// Auto-generated. Do not edit!

// (in-package laser_cb_detector.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class ConfigGoal {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.num_x = null;
      this.num_y = null;
      this.spacing_x = null;
      this.spacing_y = null;
      this.width_scaling = null;
      this.height_scaling = null;
      this.min_intensity = null;
      this.max_intensity = null;
      this.subpixel_window = null;
      this.subpixel_zero_zone = null;
      this.flip_horizontal = null;
    }
    else {
      if (initObj.hasOwnProperty('num_x')) {
        this.num_x = initObj.num_x
      }
      else {
        this.num_x = 0;
      }
      if (initObj.hasOwnProperty('num_y')) {
        this.num_y = initObj.num_y
      }
      else {
        this.num_y = 0;
      }
      if (initObj.hasOwnProperty('spacing_x')) {
        this.spacing_x = initObj.spacing_x
      }
      else {
        this.spacing_x = 0.0;
      }
      if (initObj.hasOwnProperty('spacing_y')) {
        this.spacing_y = initObj.spacing_y
      }
      else {
        this.spacing_y = 0.0;
      }
      if (initObj.hasOwnProperty('width_scaling')) {
        this.width_scaling = initObj.width_scaling
      }
      else {
        this.width_scaling = 0.0;
      }
      if (initObj.hasOwnProperty('height_scaling')) {
        this.height_scaling = initObj.height_scaling
      }
      else {
        this.height_scaling = 0.0;
      }
      if (initObj.hasOwnProperty('min_intensity')) {
        this.min_intensity = initObj.min_intensity
      }
      else {
        this.min_intensity = 0.0;
      }
      if (initObj.hasOwnProperty('max_intensity')) {
        this.max_intensity = initObj.max_intensity
      }
      else {
        this.max_intensity = 0.0;
      }
      if (initObj.hasOwnProperty('subpixel_window')) {
        this.subpixel_window = initObj.subpixel_window
      }
      else {
        this.subpixel_window = 0;
      }
      if (initObj.hasOwnProperty('subpixel_zero_zone')) {
        this.subpixel_zero_zone = initObj.subpixel_zero_zone
      }
      else {
        this.subpixel_zero_zone = 0;
      }
      if (initObj.hasOwnProperty('flip_horizontal')) {
        this.flip_horizontal = initObj.flip_horizontal
      }
      else {
        this.flip_horizontal = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ConfigGoal
    // Serialize message field [num_x]
    bufferOffset = _serializer.uint32(obj.num_x, buffer, bufferOffset);
    // Serialize message field [num_y]
    bufferOffset = _serializer.uint32(obj.num_y, buffer, bufferOffset);
    // Serialize message field [spacing_x]
    bufferOffset = _serializer.float32(obj.spacing_x, buffer, bufferOffset);
    // Serialize message field [spacing_y]
    bufferOffset = _serializer.float32(obj.spacing_y, buffer, bufferOffset);
    // Serialize message field [width_scaling]
    bufferOffset = _serializer.float32(obj.width_scaling, buffer, bufferOffset);
    // Serialize message field [height_scaling]
    bufferOffset = _serializer.float32(obj.height_scaling, buffer, bufferOffset);
    // Serialize message field [min_intensity]
    bufferOffset = _serializer.float32(obj.min_intensity, buffer, bufferOffset);
    // Serialize message field [max_intensity]
    bufferOffset = _serializer.float32(obj.max_intensity, buffer, bufferOffset);
    // Serialize message field [subpixel_window]
    bufferOffset = _serializer.uint32(obj.subpixel_window, buffer, bufferOffset);
    // Serialize message field [subpixel_zero_zone]
    bufferOffset = _serializer.int32(obj.subpixel_zero_zone, buffer, bufferOffset);
    // Serialize message field [flip_horizontal]
    bufferOffset = _serializer.uint8(obj.flip_horizontal, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ConfigGoal
    let len;
    let data = new ConfigGoal(null);
    // Deserialize message field [num_x]
    data.num_x = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [num_y]
    data.num_y = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [spacing_x]
    data.spacing_x = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [spacing_y]
    data.spacing_y = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [width_scaling]
    data.width_scaling = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [height_scaling]
    data.height_scaling = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [min_intensity]
    data.min_intensity = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [max_intensity]
    data.max_intensity = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [subpixel_window]
    data.subpixel_window = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [subpixel_zero_zone]
    data.subpixel_zero_zone = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [flip_horizontal]
    data.flip_horizontal = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 41;
  }

  static datatype() {
    // Returns string type for a message object
    return 'laser_cb_detector/ConfigGoal';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd592564bc71ebb8458e3d0d3a079d731';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # ====== DO NOT MODIFY! AUTOGENERATED FROM AN ACTION DEFINITION ======
    uint32 num_x     # Number of checkerboard corners in the X direction
    uint32 num_y     # Number of corners in the Y direction
    float32 spacing_x  # Spacing between corners in the X direction (meters)
    float32 spacing_y  # Spacing between corners in the Y direction (meters)
    
    # Specify how many times we want to upsample the image.
    #  This is often useful for detecting small checkerboards far away
    float32 width_scaling
    float32 height_scaling
    
    # Specifiy how intensity maps into a uint8. A specified window of
    #   intensities is linearly scaled to 0-255
    float32 min_intensity
    float32 max_intensity
    
    # Configure openCV's subpixel corner detector
    uint32 subpixel_window
    int32  subpixel_zero_zone
    
    # Specify if we need to flip snapshot image model. This is usually necessary
    # when the laser scans from right to left, since this is the opposite of images,
    # which are normally indexed left to right
    uint8 flip_horizontal
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ConfigGoal(null);
    if (msg.num_x !== undefined) {
      resolved.num_x = msg.num_x;
    }
    else {
      resolved.num_x = 0
    }

    if (msg.num_y !== undefined) {
      resolved.num_y = msg.num_y;
    }
    else {
      resolved.num_y = 0
    }

    if (msg.spacing_x !== undefined) {
      resolved.spacing_x = msg.spacing_x;
    }
    else {
      resolved.spacing_x = 0.0
    }

    if (msg.spacing_y !== undefined) {
      resolved.spacing_y = msg.spacing_y;
    }
    else {
      resolved.spacing_y = 0.0
    }

    if (msg.width_scaling !== undefined) {
      resolved.width_scaling = msg.width_scaling;
    }
    else {
      resolved.width_scaling = 0.0
    }

    if (msg.height_scaling !== undefined) {
      resolved.height_scaling = msg.height_scaling;
    }
    else {
      resolved.height_scaling = 0.0
    }

    if (msg.min_intensity !== undefined) {
      resolved.min_intensity = msg.min_intensity;
    }
    else {
      resolved.min_intensity = 0.0
    }

    if (msg.max_intensity !== undefined) {
      resolved.max_intensity = msg.max_intensity;
    }
    else {
      resolved.max_intensity = 0.0
    }

    if (msg.subpixel_window !== undefined) {
      resolved.subpixel_window = msg.subpixel_window;
    }
    else {
      resolved.subpixel_window = 0
    }

    if (msg.subpixel_zero_zone !== undefined) {
      resolved.subpixel_zero_zone = msg.subpixel_zero_zone;
    }
    else {
      resolved.subpixel_zero_zone = 0
    }

    if (msg.flip_horizontal !== undefined) {
      resolved.flip_horizontal = msg.flip_horizontal;
    }
    else {
      resolved.flip_horizontal = 0
    }

    return resolved;
    }
};

module.exports = ConfigGoal;
