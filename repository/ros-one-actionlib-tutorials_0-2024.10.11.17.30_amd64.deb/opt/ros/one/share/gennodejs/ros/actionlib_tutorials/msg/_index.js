
"use strict";

let AveragingResult = require('./AveragingResult.js');
let AveragingActionGoal = require('./AveragingActionGoal.js');
let AveragingActionResult = require('./AveragingActionResult.js');
let AveragingAction = require('./AveragingAction.js');
let FibonacciActionResult = require('./FibonacciActionResult.js');
let FibonacciGoal = require('./FibonacciGoal.js');
let FibonacciResult = require('./FibonacciResult.js');
let AveragingFeedback = require('./AveragingFeedback.js');
let FibonacciActionGoal = require('./FibonacciActionGoal.js');
let AveragingGoal = require('./AveragingGoal.js');
let AveragingActionFeedback = require('./AveragingActionFeedback.js');
let FibonacciActionFeedback = require('./FibonacciActionFeedback.js');
let FibonacciAction = require('./FibonacciAction.js');
let FibonacciFeedback = require('./FibonacciFeedback.js');

module.exports = {
  AveragingResult: AveragingResult,
  AveragingActionGoal: AveragingActionGoal,
  AveragingActionResult: AveragingActionResult,
  AveragingAction: AveragingAction,
  FibonacciActionResult: FibonacciActionResult,
  FibonacciGoal: FibonacciGoal,
  FibonacciResult: FibonacciResult,
  AveragingFeedback: AveragingFeedback,
  FibonacciActionGoal: FibonacciActionGoal,
  AveragingGoal: AveragingGoal,
  AveragingActionFeedback: AveragingActionFeedback,
  FibonacciActionFeedback: FibonacciActionFeedback,
  FibonacciAction: FibonacciAction,
  FibonacciFeedback: FibonacciFeedback,
};
