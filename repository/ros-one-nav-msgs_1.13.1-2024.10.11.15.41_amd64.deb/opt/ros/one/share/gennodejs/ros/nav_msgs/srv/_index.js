
"use strict";

let SetMap = require('./SetMap.js')
let GetMap = require('./GetMap.js')
let LoadMap = require('./LoadMap.js')
let GetPlan = require('./GetPlan.js')

module.exports = {
  SetMap: SetMap,
  GetMap: GetMap,
  LoadMap: LoadMap,
  GetPlan: GetPlan,
};
