
"use strict";

let CompressedAngleVectorPR2 = require('./CompressedAngleVectorPR2.js');
let SilverhammerInternalBuffer = require('./SilverhammerInternalBuffer.js');
let FC2OCSLargeData = require('./FC2OCSLargeData.js');
let AllTypeTest = require('./AllTypeTest.js');
let OCS2FC = require('./OCS2FC.js');
let HeartbeatResponse = require('./HeartbeatResponse.js');
let FC2OCS = require('./FC2OCS.js');
let WifiStatus = require('./WifiStatus.js');
let Heartbeat = require('./Heartbeat.js');
let OpenNISample = require('./OpenNISample.js');

module.exports = {
  CompressedAngleVectorPR2: CompressedAngleVectorPR2,
  SilverhammerInternalBuffer: SilverhammerInternalBuffer,
  FC2OCSLargeData: FC2OCSLargeData,
  AllTypeTest: AllTypeTest,
  OCS2FC: OCS2FC,
  HeartbeatResponse: HeartbeatResponse,
  FC2OCS: FC2OCS,
  WifiStatus: WifiStatus,
  Heartbeat: Heartbeat,
  OpenNISample: OpenNISample,
};
