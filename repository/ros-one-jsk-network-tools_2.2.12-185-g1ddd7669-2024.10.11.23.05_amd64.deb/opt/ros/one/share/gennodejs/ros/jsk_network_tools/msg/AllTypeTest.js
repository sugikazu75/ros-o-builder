// Auto-generated. Do not edit!

// (in-package jsk_network_tools.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class AllTypeTest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.bool_atom = null;
      this.bool_array = null;
      this.uint8_atom = null;
      this.uint8_array = null;
      this.int8_atom = null;
      this.int8_array = null;
      this.uint16_atom = null;
      this.uint16_array = null;
      this.int32_atom = null;
      this.int32_array = null;
      this.uint32_atom = null;
      this.uint32_array = null;
      this.int64_atom = null;
      this.int64_array = null;
      this.uint64_atom = null;
      this.uint64_array = null;
      this.float32_atom = null;
      this.float32_array = null;
      this.float64_atom = null;
      this.float64_array = null;
    }
    else {
      if (initObj.hasOwnProperty('bool_atom')) {
        this.bool_atom = initObj.bool_atom
      }
      else {
        this.bool_atom = false;
      }
      if (initObj.hasOwnProperty('bool_array')) {
        this.bool_array = initObj.bool_array
      }
      else {
        this.bool_array = new Array(4).fill(0);
      }
      if (initObj.hasOwnProperty('uint8_atom')) {
        this.uint8_atom = initObj.uint8_atom
      }
      else {
        this.uint8_atom = 0;
      }
      if (initObj.hasOwnProperty('uint8_array')) {
        this.uint8_array = initObj.uint8_array
      }
      else {
        this.uint8_array = new Array(4).fill(0);
      }
      if (initObj.hasOwnProperty('int8_atom')) {
        this.int8_atom = initObj.int8_atom
      }
      else {
        this.int8_atom = 0;
      }
      if (initObj.hasOwnProperty('int8_array')) {
        this.int8_array = initObj.int8_array
      }
      else {
        this.int8_array = new Array(4).fill(0);
      }
      if (initObj.hasOwnProperty('uint16_atom')) {
        this.uint16_atom = initObj.uint16_atom
      }
      else {
        this.uint16_atom = 0;
      }
      if (initObj.hasOwnProperty('uint16_array')) {
        this.uint16_array = initObj.uint16_array
      }
      else {
        this.uint16_array = new Array(4).fill(0);
      }
      if (initObj.hasOwnProperty('int32_atom')) {
        this.int32_atom = initObj.int32_atom
      }
      else {
        this.int32_atom = 0;
      }
      if (initObj.hasOwnProperty('int32_array')) {
        this.int32_array = initObj.int32_array
      }
      else {
        this.int32_array = new Array(4).fill(0);
      }
      if (initObj.hasOwnProperty('uint32_atom')) {
        this.uint32_atom = initObj.uint32_atom
      }
      else {
        this.uint32_atom = 0;
      }
      if (initObj.hasOwnProperty('uint32_array')) {
        this.uint32_array = initObj.uint32_array
      }
      else {
        this.uint32_array = new Array(4).fill(0);
      }
      if (initObj.hasOwnProperty('int64_atom')) {
        this.int64_atom = initObj.int64_atom
      }
      else {
        this.int64_atom = 0;
      }
      if (initObj.hasOwnProperty('int64_array')) {
        this.int64_array = initObj.int64_array
      }
      else {
        this.int64_array = new Array(4).fill(0);
      }
      if (initObj.hasOwnProperty('uint64_atom')) {
        this.uint64_atom = initObj.uint64_atom
      }
      else {
        this.uint64_atom = 0;
      }
      if (initObj.hasOwnProperty('uint64_array')) {
        this.uint64_array = initObj.uint64_array
      }
      else {
        this.uint64_array = new Array(4).fill(0);
      }
      if (initObj.hasOwnProperty('float32_atom')) {
        this.float32_atom = initObj.float32_atom
      }
      else {
        this.float32_atom = 0.0;
      }
      if (initObj.hasOwnProperty('float32_array')) {
        this.float32_array = initObj.float32_array
      }
      else {
        this.float32_array = new Array(4).fill(0);
      }
      if (initObj.hasOwnProperty('float64_atom')) {
        this.float64_atom = initObj.float64_atom
      }
      else {
        this.float64_atom = 0.0;
      }
      if (initObj.hasOwnProperty('float64_array')) {
        this.float64_array = initObj.float64_array
      }
      else {
        this.float64_array = new Array(4).fill(0);
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type AllTypeTest
    // Serialize message field [bool_atom]
    bufferOffset = _serializer.bool(obj.bool_atom, buffer, bufferOffset);
    // Check that the constant length array field [bool_array] has the right length
    if (obj.bool_array.length !== 4) {
      throw new Error('Unable to serialize array field bool_array - length must be 4')
    }
    // Serialize message field [bool_array]
    bufferOffset = _arraySerializer.bool(obj.bool_array, buffer, bufferOffset, 4);
    // Serialize message field [uint8_atom]
    bufferOffset = _serializer.uint8(obj.uint8_atom, buffer, bufferOffset);
    // Check that the constant length array field [uint8_array] has the right length
    if (obj.uint8_array.length !== 4) {
      throw new Error('Unable to serialize array field uint8_array - length must be 4')
    }
    // Serialize message field [uint8_array]
    bufferOffset = _arraySerializer.uint8(obj.uint8_array, buffer, bufferOffset, 4);
    // Serialize message field [int8_atom]
    bufferOffset = _serializer.int8(obj.int8_atom, buffer, bufferOffset);
    // Check that the constant length array field [int8_array] has the right length
    if (obj.int8_array.length !== 4) {
      throw new Error('Unable to serialize array field int8_array - length must be 4')
    }
    // Serialize message field [int8_array]
    bufferOffset = _arraySerializer.int8(obj.int8_array, buffer, bufferOffset, 4);
    // Serialize message field [uint16_atom]
    bufferOffset = _serializer.uint16(obj.uint16_atom, buffer, bufferOffset);
    // Check that the constant length array field [uint16_array] has the right length
    if (obj.uint16_array.length !== 4) {
      throw new Error('Unable to serialize array field uint16_array - length must be 4')
    }
    // Serialize message field [uint16_array]
    bufferOffset = _arraySerializer.uint16(obj.uint16_array, buffer, bufferOffset, 4);
    // Serialize message field [int32_atom]
    bufferOffset = _serializer.int32(obj.int32_atom, buffer, bufferOffset);
    // Check that the constant length array field [int32_array] has the right length
    if (obj.int32_array.length !== 4) {
      throw new Error('Unable to serialize array field int32_array - length must be 4')
    }
    // Serialize message field [int32_array]
    bufferOffset = _arraySerializer.int32(obj.int32_array, buffer, bufferOffset, 4);
    // Serialize message field [uint32_atom]
    bufferOffset = _serializer.uint32(obj.uint32_atom, buffer, bufferOffset);
    // Check that the constant length array field [uint32_array] has the right length
    if (obj.uint32_array.length !== 4) {
      throw new Error('Unable to serialize array field uint32_array - length must be 4')
    }
    // Serialize message field [uint32_array]
    bufferOffset = _arraySerializer.uint32(obj.uint32_array, buffer, bufferOffset, 4);
    // Serialize message field [int64_atom]
    bufferOffset = _serializer.int64(obj.int64_atom, buffer, bufferOffset);
    // Check that the constant length array field [int64_array] has the right length
    if (obj.int64_array.length !== 4) {
      throw new Error('Unable to serialize array field int64_array - length must be 4')
    }
    // Serialize message field [int64_array]
    bufferOffset = _arraySerializer.int64(obj.int64_array, buffer, bufferOffset, 4);
    // Serialize message field [uint64_atom]
    bufferOffset = _serializer.uint64(obj.uint64_atom, buffer, bufferOffset);
    // Check that the constant length array field [uint64_array] has the right length
    if (obj.uint64_array.length !== 4) {
      throw new Error('Unable to serialize array field uint64_array - length must be 4')
    }
    // Serialize message field [uint64_array]
    bufferOffset = _arraySerializer.uint64(obj.uint64_array, buffer, bufferOffset, 4);
    // Serialize message field [float32_atom]
    bufferOffset = _serializer.float32(obj.float32_atom, buffer, bufferOffset);
    // Check that the constant length array field [float32_array] has the right length
    if (obj.float32_array.length !== 4) {
      throw new Error('Unable to serialize array field float32_array - length must be 4')
    }
    // Serialize message field [float32_array]
    bufferOffset = _arraySerializer.float32(obj.float32_array, buffer, bufferOffset, 4);
    // Serialize message field [float64_atom]
    bufferOffset = _serializer.float64(obj.float64_atom, buffer, bufferOffset);
    // Check that the constant length array field [float64_array] has the right length
    if (obj.float64_array.length !== 4) {
      throw new Error('Unable to serialize array field float64_array - length must be 4')
    }
    // Serialize message field [float64_array]
    bufferOffset = _arraySerializer.float64(obj.float64_array, buffer, bufferOffset, 4);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type AllTypeTest
    let len;
    let data = new AllTypeTest(null);
    // Deserialize message field [bool_atom]
    data.bool_atom = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [bool_array]
    data.bool_array = _arrayDeserializer.bool(buffer, bufferOffset, 4)
    // Deserialize message field [uint8_atom]
    data.uint8_atom = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [uint8_array]
    data.uint8_array = _arrayDeserializer.uint8(buffer, bufferOffset, 4)
    // Deserialize message field [int8_atom]
    data.int8_atom = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [int8_array]
    data.int8_array = _arrayDeserializer.int8(buffer, bufferOffset, 4)
    // Deserialize message field [uint16_atom]
    data.uint16_atom = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [uint16_array]
    data.uint16_array = _arrayDeserializer.uint16(buffer, bufferOffset, 4)
    // Deserialize message field [int32_atom]
    data.int32_atom = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [int32_array]
    data.int32_array = _arrayDeserializer.int32(buffer, bufferOffset, 4)
    // Deserialize message field [uint32_atom]
    data.uint32_atom = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [uint32_array]
    data.uint32_array = _arrayDeserializer.uint32(buffer, bufferOffset, 4)
    // Deserialize message field [int64_atom]
    data.int64_atom = _deserializer.int64(buffer, bufferOffset);
    // Deserialize message field [int64_array]
    data.int64_array = _arrayDeserializer.int64(buffer, bufferOffset, 4)
    // Deserialize message field [uint64_atom]
    data.uint64_atom = _deserializer.uint64(buffer, bufferOffset);
    // Deserialize message field [uint64_array]
    data.uint64_array = _arrayDeserializer.uint64(buffer, bufferOffset, 4)
    // Deserialize message field [float32_atom]
    data.float32_atom = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [float32_array]
    data.float32_array = _arrayDeserializer.float32(buffer, bufferOffset, 4)
    // Deserialize message field [float64_atom]
    data.float64_atom = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [float64_array]
    data.float64_array = _arrayDeserializer.float64(buffer, bufferOffset, 4)
    return data;
  }

  static getMessageSize(object) {
    return 205;
  }

  static datatype() {
    // Returns string type for a message object
    return 'jsk_network_tools/AllTypeTest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'e38fde731d43d6674bf0d48497971fd6';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool       bool_atom
    bool[4]    bool_array
    uint8      uint8_atom
    uint8[4]   uint8_array
    int8       int8_atom
    int8[4]    int8_array
    uint16     uint16_atom
    uint16[4]  uint16_array
    int32      int32_atom
    int32[4]   int32_array
    uint32     uint32_atom
    uint32[4]  uint32_array
    int64      int64_atom
    int64[4]   int64_array
    uint64     uint64_atom
    uint64[4]  uint64_array
    float32    float32_atom
    float32[4] float32_array
    float64    float64_atom
    float64[4] float64_array
    
    # int8, not supported
    # string, not supported
    # time, not supported
    # duration, not supported
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new AllTypeTest(null);
    if (msg.bool_atom !== undefined) {
      resolved.bool_atom = msg.bool_atom;
    }
    else {
      resolved.bool_atom = false
    }

    if (msg.bool_array !== undefined) {
      resolved.bool_array = msg.bool_array;
    }
    else {
      resolved.bool_array = new Array(4).fill(0)
    }

    if (msg.uint8_atom !== undefined) {
      resolved.uint8_atom = msg.uint8_atom;
    }
    else {
      resolved.uint8_atom = 0
    }

    if (msg.uint8_array !== undefined) {
      resolved.uint8_array = msg.uint8_array;
    }
    else {
      resolved.uint8_array = new Array(4).fill(0)
    }

    if (msg.int8_atom !== undefined) {
      resolved.int8_atom = msg.int8_atom;
    }
    else {
      resolved.int8_atom = 0
    }

    if (msg.int8_array !== undefined) {
      resolved.int8_array = msg.int8_array;
    }
    else {
      resolved.int8_array = new Array(4).fill(0)
    }

    if (msg.uint16_atom !== undefined) {
      resolved.uint16_atom = msg.uint16_atom;
    }
    else {
      resolved.uint16_atom = 0
    }

    if (msg.uint16_array !== undefined) {
      resolved.uint16_array = msg.uint16_array;
    }
    else {
      resolved.uint16_array = new Array(4).fill(0)
    }

    if (msg.int32_atom !== undefined) {
      resolved.int32_atom = msg.int32_atom;
    }
    else {
      resolved.int32_atom = 0
    }

    if (msg.int32_array !== undefined) {
      resolved.int32_array = msg.int32_array;
    }
    else {
      resolved.int32_array = new Array(4).fill(0)
    }

    if (msg.uint32_atom !== undefined) {
      resolved.uint32_atom = msg.uint32_atom;
    }
    else {
      resolved.uint32_atom = 0
    }

    if (msg.uint32_array !== undefined) {
      resolved.uint32_array = msg.uint32_array;
    }
    else {
      resolved.uint32_array = new Array(4).fill(0)
    }

    if (msg.int64_atom !== undefined) {
      resolved.int64_atom = msg.int64_atom;
    }
    else {
      resolved.int64_atom = 0
    }

    if (msg.int64_array !== undefined) {
      resolved.int64_array = msg.int64_array;
    }
    else {
      resolved.int64_array = new Array(4).fill(0)
    }

    if (msg.uint64_atom !== undefined) {
      resolved.uint64_atom = msg.uint64_atom;
    }
    else {
      resolved.uint64_atom = 0
    }

    if (msg.uint64_array !== undefined) {
      resolved.uint64_array = msg.uint64_array;
    }
    else {
      resolved.uint64_array = new Array(4).fill(0)
    }

    if (msg.float32_atom !== undefined) {
      resolved.float32_atom = msg.float32_atom;
    }
    else {
      resolved.float32_atom = 0.0
    }

    if (msg.float32_array !== undefined) {
      resolved.float32_array = msg.float32_array;
    }
    else {
      resolved.float32_array = new Array(4).fill(0)
    }

    if (msg.float64_atom !== undefined) {
      resolved.float64_atom = msg.float64_atom;
    }
    else {
      resolved.float64_atom = 0.0
    }

    if (msg.float64_array !== undefined) {
      resolved.float64_array = msg.float64_array;
    }
    else {
      resolved.float64_array = new Array(4).fill(0)
    }

    return resolved;
    }
};

module.exports = AllTypeTest;
