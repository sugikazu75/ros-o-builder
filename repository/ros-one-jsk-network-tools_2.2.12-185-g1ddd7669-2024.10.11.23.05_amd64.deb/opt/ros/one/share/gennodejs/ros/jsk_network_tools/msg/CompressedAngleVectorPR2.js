// Auto-generated. Do not edit!

// (in-package jsk_network_tools.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class CompressedAngleVectorPR2 {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.angles = null;
    }
    else {
      if (initObj.hasOwnProperty('angles')) {
        this.angles = initObj.angles
      }
      else {
        this.angles = new Array(17).fill(0);
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type CompressedAngleVectorPR2
    // Check that the constant length array field [angles] has the right length
    if (obj.angles.length !== 17) {
      throw new Error('Unable to serialize array field angles - length must be 17')
    }
    // Serialize message field [angles]
    bufferOffset = _arraySerializer.uint8(obj.angles, buffer, bufferOffset, 17);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type CompressedAngleVectorPR2
    let len;
    let data = new CompressedAngleVectorPR2(null);
    // Deserialize message field [angles]
    data.angles = _arrayDeserializer.uint8(buffer, bufferOffset, 17)
    return data;
  }

  static getMessageSize(object) {
    return 17;
  }

  static datatype() {
    // Returns string type for a message object
    return 'jsk_network_tools/CompressedAngleVectorPR2';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '41a167b428fc98b1c378a7ba1bae8d54';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8[17] angles
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new CompressedAngleVectorPR2(null);
    if (msg.angles !== undefined) {
      resolved.angles = msg.angles;
    }
    else {
      resolved.angles = new Array(17).fill(0)
    }

    return resolved;
    }
};

module.exports = CompressedAngleVectorPR2;
