// Auto-generated. Do not edit!

// (in-package multisense_ros.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class StampedPps {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.data = null;
      this.host_time = null;
    }
    else {
      if (initObj.hasOwnProperty('data')) {
        this.data = initObj.data
      }
      else {
        this.data = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('host_time')) {
        this.host_time = initObj.host_time
      }
      else {
        this.host_time = {secs: 0, nsecs: 0};
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type StampedPps
    // Serialize message field [data]
    bufferOffset = _serializer.time(obj.data, buffer, bufferOffset);
    // Serialize message field [host_time]
    bufferOffset = _serializer.time(obj.host_time, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type StampedPps
    let len;
    let data = new StampedPps(null);
    // Deserialize message field [data]
    data.data = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [host_time]
    data.host_time = _deserializer.time(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 16;
  }

  static datatype() {
    // Returns string type for a message object
    return 'multisense_ros/StampedPps';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'ee2f8d6ea6dc30440398fb554199fa0d';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    time     data
    time     host_time
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new StampedPps(null);
    if (msg.data !== undefined) {
      resolved.data = msg.data;
    }
    else {
      resolved.data = {secs: 0, nsecs: 0}
    }

    if (msg.host_time !== undefined) {
      resolved.host_time = msg.host_time;
    }
    else {
      resolved.host_time = {secs: 0, nsecs: 0}
    }

    return resolved;
    }
};

module.exports = StampedPps;
