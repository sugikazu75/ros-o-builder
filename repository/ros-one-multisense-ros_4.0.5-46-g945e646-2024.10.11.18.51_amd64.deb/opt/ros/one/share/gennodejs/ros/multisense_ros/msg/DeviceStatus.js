// Auto-generated. Do not edit!

// (in-package multisense_ros.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class DeviceStatus {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.time = null;
      this.uptime = null;
      this.systemOk = null;
      this.laserOk = null;
      this.laserMotorOk = null;
      this.camerasOk = null;
      this.imuOk = null;
      this.externalLedsOk = null;
      this.processingPipelineOk = null;
      this.powerSupplyTemp = null;
      this.fpgaTemp = null;
      this.leftImagerTemp = null;
      this.rightImagerTemp = null;
      this.inputVoltage = null;
      this.inputCurrent = null;
      this.fpgaPower = null;
      this.logicPower = null;
      this.imagerPower = null;
    }
    else {
      if (initObj.hasOwnProperty('time')) {
        this.time = initObj.time
      }
      else {
        this.time = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('uptime')) {
        this.uptime = initObj.uptime
      }
      else {
        this.uptime = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('systemOk')) {
        this.systemOk = initObj.systemOk
      }
      else {
        this.systemOk = false;
      }
      if (initObj.hasOwnProperty('laserOk')) {
        this.laserOk = initObj.laserOk
      }
      else {
        this.laserOk = false;
      }
      if (initObj.hasOwnProperty('laserMotorOk')) {
        this.laserMotorOk = initObj.laserMotorOk
      }
      else {
        this.laserMotorOk = false;
      }
      if (initObj.hasOwnProperty('camerasOk')) {
        this.camerasOk = initObj.camerasOk
      }
      else {
        this.camerasOk = false;
      }
      if (initObj.hasOwnProperty('imuOk')) {
        this.imuOk = initObj.imuOk
      }
      else {
        this.imuOk = false;
      }
      if (initObj.hasOwnProperty('externalLedsOk')) {
        this.externalLedsOk = initObj.externalLedsOk
      }
      else {
        this.externalLedsOk = false;
      }
      if (initObj.hasOwnProperty('processingPipelineOk')) {
        this.processingPipelineOk = initObj.processingPipelineOk
      }
      else {
        this.processingPipelineOk = false;
      }
      if (initObj.hasOwnProperty('powerSupplyTemp')) {
        this.powerSupplyTemp = initObj.powerSupplyTemp
      }
      else {
        this.powerSupplyTemp = 0.0;
      }
      if (initObj.hasOwnProperty('fpgaTemp')) {
        this.fpgaTemp = initObj.fpgaTemp
      }
      else {
        this.fpgaTemp = 0.0;
      }
      if (initObj.hasOwnProperty('leftImagerTemp')) {
        this.leftImagerTemp = initObj.leftImagerTemp
      }
      else {
        this.leftImagerTemp = 0.0;
      }
      if (initObj.hasOwnProperty('rightImagerTemp')) {
        this.rightImagerTemp = initObj.rightImagerTemp
      }
      else {
        this.rightImagerTemp = 0.0;
      }
      if (initObj.hasOwnProperty('inputVoltage')) {
        this.inputVoltage = initObj.inputVoltage
      }
      else {
        this.inputVoltage = 0.0;
      }
      if (initObj.hasOwnProperty('inputCurrent')) {
        this.inputCurrent = initObj.inputCurrent
      }
      else {
        this.inputCurrent = 0.0;
      }
      if (initObj.hasOwnProperty('fpgaPower')) {
        this.fpgaPower = initObj.fpgaPower
      }
      else {
        this.fpgaPower = 0.0;
      }
      if (initObj.hasOwnProperty('logicPower')) {
        this.logicPower = initObj.logicPower
      }
      else {
        this.logicPower = 0.0;
      }
      if (initObj.hasOwnProperty('imagerPower')) {
        this.imagerPower = initObj.imagerPower
      }
      else {
        this.imagerPower = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type DeviceStatus
    // Serialize message field [time]
    bufferOffset = _serializer.time(obj.time, buffer, bufferOffset);
    // Serialize message field [uptime]
    bufferOffset = _serializer.time(obj.uptime, buffer, bufferOffset);
    // Serialize message field [systemOk]
    bufferOffset = _serializer.bool(obj.systemOk, buffer, bufferOffset);
    // Serialize message field [laserOk]
    bufferOffset = _serializer.bool(obj.laserOk, buffer, bufferOffset);
    // Serialize message field [laserMotorOk]
    bufferOffset = _serializer.bool(obj.laserMotorOk, buffer, bufferOffset);
    // Serialize message field [camerasOk]
    bufferOffset = _serializer.bool(obj.camerasOk, buffer, bufferOffset);
    // Serialize message field [imuOk]
    bufferOffset = _serializer.bool(obj.imuOk, buffer, bufferOffset);
    // Serialize message field [externalLedsOk]
    bufferOffset = _serializer.bool(obj.externalLedsOk, buffer, bufferOffset);
    // Serialize message field [processingPipelineOk]
    bufferOffset = _serializer.bool(obj.processingPipelineOk, buffer, bufferOffset);
    // Serialize message field [powerSupplyTemp]
    bufferOffset = _serializer.float32(obj.powerSupplyTemp, buffer, bufferOffset);
    // Serialize message field [fpgaTemp]
    bufferOffset = _serializer.float32(obj.fpgaTemp, buffer, bufferOffset);
    // Serialize message field [leftImagerTemp]
    bufferOffset = _serializer.float32(obj.leftImagerTemp, buffer, bufferOffset);
    // Serialize message field [rightImagerTemp]
    bufferOffset = _serializer.float32(obj.rightImagerTemp, buffer, bufferOffset);
    // Serialize message field [inputVoltage]
    bufferOffset = _serializer.float32(obj.inputVoltage, buffer, bufferOffset);
    // Serialize message field [inputCurrent]
    bufferOffset = _serializer.float32(obj.inputCurrent, buffer, bufferOffset);
    // Serialize message field [fpgaPower]
    bufferOffset = _serializer.float32(obj.fpgaPower, buffer, bufferOffset);
    // Serialize message field [logicPower]
    bufferOffset = _serializer.float32(obj.logicPower, buffer, bufferOffset);
    // Serialize message field [imagerPower]
    bufferOffset = _serializer.float32(obj.imagerPower, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type DeviceStatus
    let len;
    let data = new DeviceStatus(null);
    // Deserialize message field [time]
    data.time = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [uptime]
    data.uptime = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [systemOk]
    data.systemOk = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [laserOk]
    data.laserOk = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [laserMotorOk]
    data.laserMotorOk = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [camerasOk]
    data.camerasOk = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [imuOk]
    data.imuOk = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [externalLedsOk]
    data.externalLedsOk = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [processingPipelineOk]
    data.processingPipelineOk = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [powerSupplyTemp]
    data.powerSupplyTemp = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [fpgaTemp]
    data.fpgaTemp = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [leftImagerTemp]
    data.leftImagerTemp = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [rightImagerTemp]
    data.rightImagerTemp = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [inputVoltage]
    data.inputVoltage = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [inputCurrent]
    data.inputCurrent = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [fpgaPower]
    data.fpgaPower = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [logicPower]
    data.logicPower = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [imagerPower]
    data.imagerPower = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 59;
  }

  static datatype() {
    // Returns string type for a message object
    return 'multisense_ros/DeviceStatus';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '2114c900161a6607a8d4a04b3cecd16b';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    time time
    time uptime
    bool systemOk
    bool laserOk
    bool laserMotorOk
    bool camerasOk
    bool imuOk
    bool externalLedsOk
    bool processingPipelineOk
    float32 powerSupplyTemp
    float32 fpgaTemp
    float32 leftImagerTemp
    float32 rightImagerTemp
    float32 inputVoltage
    float32 inputCurrent
    float32 fpgaPower
    float32 logicPower
    float32 imagerPower
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new DeviceStatus(null);
    if (msg.time !== undefined) {
      resolved.time = msg.time;
    }
    else {
      resolved.time = {secs: 0, nsecs: 0}
    }

    if (msg.uptime !== undefined) {
      resolved.uptime = msg.uptime;
    }
    else {
      resolved.uptime = {secs: 0, nsecs: 0}
    }

    if (msg.systemOk !== undefined) {
      resolved.systemOk = msg.systemOk;
    }
    else {
      resolved.systemOk = false
    }

    if (msg.laserOk !== undefined) {
      resolved.laserOk = msg.laserOk;
    }
    else {
      resolved.laserOk = false
    }

    if (msg.laserMotorOk !== undefined) {
      resolved.laserMotorOk = msg.laserMotorOk;
    }
    else {
      resolved.laserMotorOk = false
    }

    if (msg.camerasOk !== undefined) {
      resolved.camerasOk = msg.camerasOk;
    }
    else {
      resolved.camerasOk = false
    }

    if (msg.imuOk !== undefined) {
      resolved.imuOk = msg.imuOk;
    }
    else {
      resolved.imuOk = false
    }

    if (msg.externalLedsOk !== undefined) {
      resolved.externalLedsOk = msg.externalLedsOk;
    }
    else {
      resolved.externalLedsOk = false
    }

    if (msg.processingPipelineOk !== undefined) {
      resolved.processingPipelineOk = msg.processingPipelineOk;
    }
    else {
      resolved.processingPipelineOk = false
    }

    if (msg.powerSupplyTemp !== undefined) {
      resolved.powerSupplyTemp = msg.powerSupplyTemp;
    }
    else {
      resolved.powerSupplyTemp = 0.0
    }

    if (msg.fpgaTemp !== undefined) {
      resolved.fpgaTemp = msg.fpgaTemp;
    }
    else {
      resolved.fpgaTemp = 0.0
    }

    if (msg.leftImagerTemp !== undefined) {
      resolved.leftImagerTemp = msg.leftImagerTemp;
    }
    else {
      resolved.leftImagerTemp = 0.0
    }

    if (msg.rightImagerTemp !== undefined) {
      resolved.rightImagerTemp = msg.rightImagerTemp;
    }
    else {
      resolved.rightImagerTemp = 0.0
    }

    if (msg.inputVoltage !== undefined) {
      resolved.inputVoltage = msg.inputVoltage;
    }
    else {
      resolved.inputVoltage = 0.0
    }

    if (msg.inputCurrent !== undefined) {
      resolved.inputCurrent = msg.inputCurrent;
    }
    else {
      resolved.inputCurrent = 0.0
    }

    if (msg.fpgaPower !== undefined) {
      resolved.fpgaPower = msg.fpgaPower;
    }
    else {
      resolved.fpgaPower = 0.0
    }

    if (msg.logicPower !== undefined) {
      resolved.logicPower = msg.logicPower;
    }
    else {
      resolved.logicPower = 0.0
    }

    if (msg.imagerPower !== undefined) {
      resolved.imagerPower = msg.imagerPower;
    }
    else {
      resolved.imagerPower = 0.0
    }

    return resolved;
    }
};

module.exports = DeviceStatus;
