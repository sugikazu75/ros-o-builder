// Auto-generated. Do not edit!

// (in-package fingertip_pressure.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class PressureInfoElement {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.frame_id = null;
      this.center = null;
      this.halfside1 = null;
      this.halfside2 = null;
      this.force_per_unit = null;
    }
    else {
      if (initObj.hasOwnProperty('frame_id')) {
        this.frame_id = initObj.frame_id
      }
      else {
        this.frame_id = '';
      }
      if (initObj.hasOwnProperty('center')) {
        this.center = initObj.center
      }
      else {
        this.center = [];
      }
      if (initObj.hasOwnProperty('halfside1')) {
        this.halfside1 = initObj.halfside1
      }
      else {
        this.halfside1 = [];
      }
      if (initObj.hasOwnProperty('halfside2')) {
        this.halfside2 = initObj.halfside2
      }
      else {
        this.halfside2 = [];
      }
      if (initObj.hasOwnProperty('force_per_unit')) {
        this.force_per_unit = initObj.force_per_unit
      }
      else {
        this.force_per_unit = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PressureInfoElement
    // Serialize message field [frame_id]
    bufferOffset = _serializer.string(obj.frame_id, buffer, bufferOffset);
    // Serialize message field [center]
    // Serialize the length for message field [center]
    bufferOffset = _serializer.uint32(obj.center.length, buffer, bufferOffset);
    obj.center.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Vector3.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [halfside1]
    // Serialize the length for message field [halfside1]
    bufferOffset = _serializer.uint32(obj.halfside1.length, buffer, bufferOffset);
    obj.halfside1.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Vector3.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [halfside2]
    // Serialize the length for message field [halfside2]
    bufferOffset = _serializer.uint32(obj.halfside2.length, buffer, bufferOffset);
    obj.halfside2.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Vector3.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [force_per_unit]
    bufferOffset = _arraySerializer.float64(obj.force_per_unit, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PressureInfoElement
    let len;
    let data = new PressureInfoElement(null);
    // Deserialize message field [frame_id]
    data.frame_id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [center]
    // Deserialize array length for message field [center]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.center = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.center[i] = geometry_msgs.msg.Vector3.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [halfside1]
    // Deserialize array length for message field [halfside1]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.halfside1 = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.halfside1[i] = geometry_msgs.msg.Vector3.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [halfside2]
    // Deserialize array length for message field [halfside2]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.halfside2 = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.halfside2[i] = geometry_msgs.msg.Vector3.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [force_per_unit]
    data.force_per_unit = _arrayDeserializer.float64(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.frame_id);
    length += 24 * object.center.length;
    length += 24 * object.halfside1.length;
    length += 24 * object.halfside2.length;
    length += 8 * object.force_per_unit.length;
    return length + 20;
  }

  static datatype() {
    // Returns string type for a message object
    return 'fingertip_pressure/PressureInfoElement';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '1cb486bb542ab85e1ff8d84fe9cc899f';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string frame_id # Frame ID
    geometry_msgs/Vector3[] center # Corner of sensor (meters)
    geometry_msgs/Vector3[] halfside1 # Half of one edge of sensor (meters)
    geometry_msgs/Vector3[] halfside2 # Half of perpendicular edge of sensor (meters)
    # Sensor corners are at center+-halfside1+-halfside2
    # Cross product of halfside1 and halfside2 points out
    float64[] force_per_unit # Multiply this by the raw sensor value to get a force
    
    ================================================================================
    MSG: geometry_msgs/Vector3
    # This represents a vector in free space. 
    # It is only meant to represent a direction. Therefore, it does not
    # make sense to apply a translation to it (e.g., when applying a 
    # generic rigid transformation to a Vector3, tf2 will only apply the
    # rotation). If you want your data to be translatable too, use the
    # geometry_msgs/Point message instead.
    
    float64 x
    float64 y
    float64 z
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PressureInfoElement(null);
    if (msg.frame_id !== undefined) {
      resolved.frame_id = msg.frame_id;
    }
    else {
      resolved.frame_id = ''
    }

    if (msg.center !== undefined) {
      resolved.center = new Array(msg.center.length);
      for (let i = 0; i < resolved.center.length; ++i) {
        resolved.center[i] = geometry_msgs.msg.Vector3.Resolve(msg.center[i]);
      }
    }
    else {
      resolved.center = []
    }

    if (msg.halfside1 !== undefined) {
      resolved.halfside1 = new Array(msg.halfside1.length);
      for (let i = 0; i < resolved.halfside1.length; ++i) {
        resolved.halfside1[i] = geometry_msgs.msg.Vector3.Resolve(msg.halfside1[i]);
      }
    }
    else {
      resolved.halfside1 = []
    }

    if (msg.halfside2 !== undefined) {
      resolved.halfside2 = new Array(msg.halfside2.length);
      for (let i = 0; i < resolved.halfside2.length; ++i) {
        resolved.halfside2[i] = geometry_msgs.msg.Vector3.Resolve(msg.halfside2[i]);
      }
    }
    else {
      resolved.halfside2 = []
    }

    if (msg.force_per_unit !== undefined) {
      resolved.force_per_unit = msg.force_per_unit;
    }
    else {
      resolved.force_per_unit = []
    }

    return resolved;
    }
};

module.exports = PressureInfoElement;
