# fingertip_pressure initialization file
