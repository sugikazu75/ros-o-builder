
"use strict";

let SetSpeedSliderFraction = require('./SetSpeedSliderFraction.js')
let SetAnalogOutput = require('./SetAnalogOutput.js')
let SetPayload = require('./SetPayload.js')
let SetIO = require('./SetIO.js')
let GetRobotSoftwareVersion = require('./GetRobotSoftwareVersion.js')

module.exports = {
  SetSpeedSliderFraction: SetSpeedSliderFraction,
  SetAnalogOutput: SetAnalogOutput,
  SetPayload: SetPayload,
  SetIO: SetIO,
  GetRobotSoftwareVersion: GetRobotSoftwareVersion,
};
