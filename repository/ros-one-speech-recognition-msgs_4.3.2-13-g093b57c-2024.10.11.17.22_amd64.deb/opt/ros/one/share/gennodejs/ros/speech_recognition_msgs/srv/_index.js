
"use strict";

let SpeechRecognition = require('./SpeechRecognition.js')

module.exports = {
  SpeechRecognition: SpeechRecognition,
};
