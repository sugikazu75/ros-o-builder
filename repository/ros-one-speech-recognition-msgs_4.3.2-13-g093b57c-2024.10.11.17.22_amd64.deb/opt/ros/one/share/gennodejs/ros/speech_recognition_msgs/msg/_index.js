
"use strict";

let PhraseRule = require('./PhraseRule.js');
let SpeechRecognitionCandidates = require('./SpeechRecognitionCandidates.js');
let Vocabulary = require('./Vocabulary.js');
let Grammar = require('./Grammar.js');

module.exports = {
  PhraseRule: PhraseRule,
  SpeechRecognitionCandidates: SpeechRecognitionCandidates,
  Vocabulary: Vocabulary,
  Grammar: Grammar,
};
