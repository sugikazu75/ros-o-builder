// Auto-generated. Do not edit!

// (in-package axis_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class Ptz {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.pan = null;
      this.tilt = null;
      this.zoom = null;
    }
    else {
      if (initObj.hasOwnProperty('pan')) {
        this.pan = initObj.pan
      }
      else {
        this.pan = 0.0;
      }
      if (initObj.hasOwnProperty('tilt')) {
        this.tilt = initObj.tilt
      }
      else {
        this.tilt = 0.0;
      }
      if (initObj.hasOwnProperty('zoom')) {
        this.zoom = initObj.zoom
      }
      else {
        this.zoom = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Ptz
    // Serialize message field [pan]
    bufferOffset = _serializer.float32(obj.pan, buffer, bufferOffset);
    // Serialize message field [tilt]
    bufferOffset = _serializer.float32(obj.tilt, buffer, bufferOffset);
    // Serialize message field [zoom]
    bufferOffset = _serializer.float32(obj.zoom, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Ptz
    let len;
    let data = new Ptz(null);
    // Deserialize message field [pan]
    data.pan = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [tilt]
    data.tilt = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [zoom]
    data.zoom = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 12;
  }

  static datatype() {
    // Returns string type for a message object
    return 'axis_msgs/Ptz';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'eef4827ef5b8ba89a8c9fa0810a30294';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # The pan position or velocity of the camera, in radians or rad/s
    # 0.0 is forward / stopped
    # + is to the left (anticlockwise)
    # - is to the right (clockwise)
    # Valid ranges:
    #  position: -pi to pi
    #  speed: -2.61 to +2.61 (max 150 deg/s)
    float32 pan
    
    # The tilt position or velocity of the camera, in radians or rad/s
    # 0.0 is parallel with the camera's base / stopped
    # + is upward
    # - is downward
    # Valid ranges:
    #  position: -pi/2 to pi/2
    #  speed: -2.61 to +2.61 (max 150 deg/s)
    float32 tilt
    
    # The camera's zoom level or speed
    # The allowed range varies depending on whether we're using position or velocity control
    # Valid ranges:
    #  position: 0 to 9999
    #  speed: -100 to 100
    float32 zoom
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Ptz(null);
    if (msg.pan !== undefined) {
      resolved.pan = msg.pan;
    }
    else {
      resolved.pan = 0.0
    }

    if (msg.tilt !== undefined) {
      resolved.tilt = msg.tilt;
    }
    else {
      resolved.tilt = 0.0
    }

    if (msg.zoom !== undefined) {
      resolved.zoom = msg.zoom;
    }
    else {
      resolved.zoom = 0.0
    }

    return resolved;
    }
};

module.exports = Ptz;
