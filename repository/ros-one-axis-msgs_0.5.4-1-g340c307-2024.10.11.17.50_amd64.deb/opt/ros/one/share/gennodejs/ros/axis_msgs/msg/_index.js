
"use strict";

let Axis = require('./Axis.js');
let Ptz = require('./Ptz.js');

module.exports = {
  Axis: Axis,
  Ptz: Ptz,
};
