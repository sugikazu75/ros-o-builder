
"use strict";

let TestRequestResult = require('./TestRequestResult.js');
let TwoIntsActionFeedback = require('./TwoIntsActionFeedback.js');
let TestActionGoal = require('./TestActionGoal.js');
let TestActionFeedback = require('./TestActionFeedback.js');
let TestRequestActionGoal = require('./TestRequestActionGoal.js');
let TwoIntsResult = require('./TwoIntsResult.js');
let TestRequestActionResult = require('./TestRequestActionResult.js');
let TwoIntsGoal = require('./TwoIntsGoal.js');
let TestActionResult = require('./TestActionResult.js');
let TestRequestActionFeedback = require('./TestRequestActionFeedback.js');
let TestResult = require('./TestResult.js');
let TestRequestFeedback = require('./TestRequestFeedback.js');
let TestFeedback = require('./TestFeedback.js');
let TestRequestGoal = require('./TestRequestGoal.js');
let TestGoal = require('./TestGoal.js');
let TwoIntsActionResult = require('./TwoIntsActionResult.js');
let TwoIntsActionGoal = require('./TwoIntsActionGoal.js');
let TestRequestAction = require('./TestRequestAction.js');
let TwoIntsFeedback = require('./TwoIntsFeedback.js');
let TestAction = require('./TestAction.js');
let TwoIntsAction = require('./TwoIntsAction.js');

module.exports = {
  TestRequestResult: TestRequestResult,
  TwoIntsActionFeedback: TwoIntsActionFeedback,
  TestActionGoal: TestActionGoal,
  TestActionFeedback: TestActionFeedback,
  TestRequestActionGoal: TestRequestActionGoal,
  TwoIntsResult: TwoIntsResult,
  TestRequestActionResult: TestRequestActionResult,
  TwoIntsGoal: TwoIntsGoal,
  TestActionResult: TestActionResult,
  TestRequestActionFeedback: TestRequestActionFeedback,
  TestResult: TestResult,
  TestRequestFeedback: TestRequestFeedback,
  TestFeedback: TestFeedback,
  TestRequestGoal: TestRequestGoal,
  TestGoal: TestGoal,
  TwoIntsActionResult: TwoIntsActionResult,
  TwoIntsActionGoal: TwoIntsActionGoal,
  TestRequestAction: TestRequestAction,
  TwoIntsFeedback: TwoIntsFeedback,
  TestAction: TestAction,
  TwoIntsAction: TwoIntsAction,
};
