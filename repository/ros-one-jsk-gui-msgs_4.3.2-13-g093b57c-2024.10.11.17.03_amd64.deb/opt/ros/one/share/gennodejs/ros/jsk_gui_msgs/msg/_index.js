
"use strict";

let SlackMessage = require('./SlackMessage.js');
let Action = require('./Action.js');
let Tablet = require('./Tablet.js');
let TouchEvent = require('./TouchEvent.js');
let MagneticField = require('./MagneticField.js');
let Gravity = require('./Gravity.js');
let MultiTouch = require('./MultiTouch.js');
let Touch = require('./Touch.js');
let DeviceSensor = require('./DeviceSensor.js');
let VoiceMessage = require('./VoiceMessage.js');
let AndroidSensor = require('./AndroidSensor.js');

module.exports = {
  SlackMessage: SlackMessage,
  Action: Action,
  Tablet: Tablet,
  TouchEvent: TouchEvent,
  MagneticField: MagneticField,
  Gravity: Gravity,
  MultiTouch: MultiTouch,
  Touch: Touch,
  DeviceSensor: DeviceSensor,
  VoiceMessage: VoiceMessage,
  AndroidSensor: AndroidSensor,
};
