
"use strict";

let Velocity = require('./Velocity.js');
let ShapeFeedback = require('./ShapeFeedback.js');
let ShapeActionFeedback = require('./ShapeActionFeedback.js');
let ShapeActionGoal = require('./ShapeActionGoal.js');
let ShapeResult = require('./ShapeResult.js');
let ShapeGoal = require('./ShapeGoal.js');
let ShapeAction = require('./ShapeAction.js');
let ShapeActionResult = require('./ShapeActionResult.js');

module.exports = {
  Velocity: Velocity,
  ShapeFeedback: ShapeFeedback,
  ShapeActionFeedback: ShapeActionFeedback,
  ShapeActionGoal: ShapeActionGoal,
  ShapeResult: ShapeResult,
  ShapeGoal: ShapeGoal,
  ShapeAction: ShapeAction,
  ShapeActionResult: ShapeActionResult,
};
