// Auto-generated. Do not edit!

// (in-package pgm_learner.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let LinearGaussianNodeState = require('./LinearGaussianNodeState.js');

//-----------------------------------------------------------

class LinearGaussianGraphState {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.node_states = null;
    }
    else {
      if (initObj.hasOwnProperty('node_states')) {
        this.node_states = initObj.node_states
      }
      else {
        this.node_states = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type LinearGaussianGraphState
    // Serialize message field [node_states]
    // Serialize the length for message field [node_states]
    bufferOffset = _serializer.uint32(obj.node_states.length, buffer, bufferOffset);
    obj.node_states.forEach((val) => {
      bufferOffset = LinearGaussianNodeState.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type LinearGaussianGraphState
    let len;
    let data = new LinearGaussianGraphState(null);
    // Deserialize message field [node_states]
    // Deserialize array length for message field [node_states]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.node_states = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.node_states[i] = LinearGaussianNodeState.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.node_states.forEach((val) => {
      length += LinearGaussianNodeState.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'pgm_learner/LinearGaussianGraphState';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'f6ac09f794ac42baad4ddfb93fc0a69c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    pgm_learner/LinearGaussianNodeState[] node_states
    
    ================================================================================
    MSG: pgm_learner/LinearGaussianNodeState
    string node
    float32 state
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new LinearGaussianGraphState(null);
    if (msg.node_states !== undefined) {
      resolved.node_states = new Array(msg.node_states.length);
      for (let i = 0; i < resolved.node_states.length; ++i) {
        resolved.node_states[i] = LinearGaussianNodeState.Resolve(msg.node_states[i]);
      }
    }
    else {
      resolved.node_states = []
    }

    return resolved;
    }
};

module.exports = LinearGaussianGraphState;
