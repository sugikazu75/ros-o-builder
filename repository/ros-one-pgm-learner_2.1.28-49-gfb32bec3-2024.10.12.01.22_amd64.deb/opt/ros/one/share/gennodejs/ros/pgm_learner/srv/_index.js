
"use strict";

let DiscreteParameterEstimation = require('./DiscreteParameterEstimation.js')
let DiscreteQuery = require('./DiscreteQuery.js')
let LinearGaussianParameterEstimation = require('./LinearGaussianParameterEstimation.js')
let LinearGaussianStructureEstimation = require('./LinearGaussianStructureEstimation.js')
let DiscreteStructureEstimation = require('./DiscreteStructureEstimation.js')

module.exports = {
  DiscreteParameterEstimation: DiscreteParameterEstimation,
  DiscreteQuery: DiscreteQuery,
  LinearGaussianParameterEstimation: LinearGaussianParameterEstimation,
  LinearGaussianStructureEstimation: LinearGaussianStructureEstimation,
  DiscreteStructureEstimation: DiscreteStructureEstimation,
};
