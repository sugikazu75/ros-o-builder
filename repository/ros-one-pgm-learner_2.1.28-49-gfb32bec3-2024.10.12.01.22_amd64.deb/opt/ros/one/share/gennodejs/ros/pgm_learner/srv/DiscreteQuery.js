// Auto-generated. Do not edit!

// (in-package pgm_learner.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let DiscreteNode = require('../msg/DiscreteNode.js');
let DiscreteNodeState = require('../msg/DiscreteNodeState.js');

//-----------------------------------------------------------


//-----------------------------------------------------------

class DiscreteQueryRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.nodes = null;
      this.evidence = null;
      this.query = null;
    }
    else {
      if (initObj.hasOwnProperty('nodes')) {
        this.nodes = initObj.nodes
      }
      else {
        this.nodes = [];
      }
      if (initObj.hasOwnProperty('evidence')) {
        this.evidence = initObj.evidence
      }
      else {
        this.evidence = [];
      }
      if (initObj.hasOwnProperty('query')) {
        this.query = initObj.query
      }
      else {
        this.query = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type DiscreteQueryRequest
    // Serialize message field [nodes]
    // Serialize the length for message field [nodes]
    bufferOffset = _serializer.uint32(obj.nodes.length, buffer, bufferOffset);
    obj.nodes.forEach((val) => {
      bufferOffset = DiscreteNode.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [evidence]
    // Serialize the length for message field [evidence]
    bufferOffset = _serializer.uint32(obj.evidence.length, buffer, bufferOffset);
    obj.evidence.forEach((val) => {
      bufferOffset = DiscreteNodeState.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [query]
    bufferOffset = _arraySerializer.string(obj.query, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type DiscreteQueryRequest
    let len;
    let data = new DiscreteQueryRequest(null);
    // Deserialize message field [nodes]
    // Deserialize array length for message field [nodes]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.nodes = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.nodes[i] = DiscreteNode.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [evidence]
    // Deserialize array length for message field [evidence]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.evidence = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.evidence[i] = DiscreteNodeState.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [query]
    data.query = _arrayDeserializer.string(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.nodes.forEach((val) => {
      length += DiscreteNode.getMessageSize(val);
    });
    object.evidence.forEach((val) => {
      length += DiscreteNodeState.getMessageSize(val);
    });
    object.query.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    return length + 12;
  }

  static datatype() {
    // Returns string type for a service object
    return 'pgm_learner/DiscreteQueryRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'ed89305a3a26318e54824e9039449857';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    pgm_learner/DiscreteNode[] nodes # information of each nodes
    pgm_learner/DiscreteNodeState[] evidence # evidnce
    string[] query # query
    
    ================================================================================
    MSG: pgm_learner/DiscreteNode
    string name
    string[] outcomes
    string[] parents
    string[] children
    pgm_learner/ConditionalProbability[] CPT
    
    ================================================================================
    MSG: pgm_learner/ConditionalProbability
    string[]  values
    float32[] probabilities
    
    ================================================================================
    MSG: pgm_learner/DiscreteNodeState
    string node
    string state
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new DiscreteQueryRequest(null);
    if (msg.nodes !== undefined) {
      resolved.nodes = new Array(msg.nodes.length);
      for (let i = 0; i < resolved.nodes.length; ++i) {
        resolved.nodes[i] = DiscreteNode.Resolve(msg.nodes[i]);
      }
    }
    else {
      resolved.nodes = []
    }

    if (msg.evidence !== undefined) {
      resolved.evidence = new Array(msg.evidence.length);
      for (let i = 0; i < resolved.evidence.length; ++i) {
        resolved.evidence[i] = DiscreteNodeState.Resolve(msg.evidence[i]);
      }
    }
    else {
      resolved.evidence = []
    }

    if (msg.query !== undefined) {
      resolved.query = msg.query;
    }
    else {
      resolved.query = []
    }

    return resolved;
    }
};

class DiscreteQueryResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.nodes = null;
    }
    else {
      if (initObj.hasOwnProperty('nodes')) {
        this.nodes = initObj.nodes
      }
      else {
        this.nodes = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type DiscreteQueryResponse
    // Serialize message field [nodes]
    // Serialize the length for message field [nodes]
    bufferOffset = _serializer.uint32(obj.nodes.length, buffer, bufferOffset);
    obj.nodes.forEach((val) => {
      bufferOffset = DiscreteNode.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type DiscreteQueryResponse
    let len;
    let data = new DiscreteQueryResponse(null);
    // Deserialize message field [nodes]
    // Deserialize array length for message field [nodes]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.nodes = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.nodes[i] = DiscreteNode.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.nodes.forEach((val) => {
      length += DiscreteNode.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'pgm_learner/DiscreteQueryResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c8f93aadf5ce2cc57073d952e12833e1';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    pgm_learner/DiscreteNode[] nodes # information of each nodes
    
    
    ================================================================================
    MSG: pgm_learner/DiscreteNode
    string name
    string[] outcomes
    string[] parents
    string[] children
    pgm_learner/ConditionalProbability[] CPT
    
    ================================================================================
    MSG: pgm_learner/ConditionalProbability
    string[]  values
    float32[] probabilities
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new DiscreteQueryResponse(null);
    if (msg.nodes !== undefined) {
      resolved.nodes = new Array(msg.nodes.length);
      for (let i = 0; i < resolved.nodes.length; ++i) {
        resolved.nodes[i] = DiscreteNode.Resolve(msg.nodes[i]);
      }
    }
    else {
      resolved.nodes = []
    }

    return resolved;
    }
};

module.exports = {
  Request: DiscreteQueryRequest,
  Response: DiscreteQueryResponse,
  md5sum() { return '268044a2749deb7a93e17566a63deb21'; },
  datatype() { return 'pgm_learner/DiscreteQuery'; }
};
