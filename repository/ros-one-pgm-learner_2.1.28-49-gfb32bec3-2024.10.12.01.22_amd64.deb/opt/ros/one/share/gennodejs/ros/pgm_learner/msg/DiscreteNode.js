// Auto-generated. Do not edit!

// (in-package pgm_learner.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let ConditionalProbability = require('./ConditionalProbability.js');

//-----------------------------------------------------------

class DiscreteNode {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.name = null;
      this.outcomes = null;
      this.parents = null;
      this.children = null;
      this.CPT = null;
    }
    else {
      if (initObj.hasOwnProperty('name')) {
        this.name = initObj.name
      }
      else {
        this.name = '';
      }
      if (initObj.hasOwnProperty('outcomes')) {
        this.outcomes = initObj.outcomes
      }
      else {
        this.outcomes = [];
      }
      if (initObj.hasOwnProperty('parents')) {
        this.parents = initObj.parents
      }
      else {
        this.parents = [];
      }
      if (initObj.hasOwnProperty('children')) {
        this.children = initObj.children
      }
      else {
        this.children = [];
      }
      if (initObj.hasOwnProperty('CPT')) {
        this.CPT = initObj.CPT
      }
      else {
        this.CPT = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type DiscreteNode
    // Serialize message field [name]
    bufferOffset = _serializer.string(obj.name, buffer, bufferOffset);
    // Serialize message field [outcomes]
    bufferOffset = _arraySerializer.string(obj.outcomes, buffer, bufferOffset, null);
    // Serialize message field [parents]
    bufferOffset = _arraySerializer.string(obj.parents, buffer, bufferOffset, null);
    // Serialize message field [children]
    bufferOffset = _arraySerializer.string(obj.children, buffer, bufferOffset, null);
    // Serialize message field [CPT]
    // Serialize the length for message field [CPT]
    bufferOffset = _serializer.uint32(obj.CPT.length, buffer, bufferOffset);
    obj.CPT.forEach((val) => {
      bufferOffset = ConditionalProbability.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type DiscreteNode
    let len;
    let data = new DiscreteNode(null);
    // Deserialize message field [name]
    data.name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [outcomes]
    data.outcomes = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [parents]
    data.parents = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [children]
    data.children = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [CPT]
    // Deserialize array length for message field [CPT]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.CPT = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.CPT[i] = ConditionalProbability.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.name);
    object.outcomes.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    object.parents.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    object.children.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    object.CPT.forEach((val) => {
      length += ConditionalProbability.getMessageSize(val);
    });
    return length + 20;
  }

  static datatype() {
    // Returns string type for a message object
    return 'pgm_learner/DiscreteNode';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '4342c6b20fde889181ce34955023e453';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string name
    string[] outcomes
    string[] parents
    string[] children
    pgm_learner/ConditionalProbability[] CPT
    
    ================================================================================
    MSG: pgm_learner/ConditionalProbability
    string[]  values
    float32[] probabilities
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new DiscreteNode(null);
    if (msg.name !== undefined) {
      resolved.name = msg.name;
    }
    else {
      resolved.name = ''
    }

    if (msg.outcomes !== undefined) {
      resolved.outcomes = msg.outcomes;
    }
    else {
      resolved.outcomes = []
    }

    if (msg.parents !== undefined) {
      resolved.parents = msg.parents;
    }
    else {
      resolved.parents = []
    }

    if (msg.children !== undefined) {
      resolved.children = msg.children;
    }
    else {
      resolved.children = []
    }

    if (msg.CPT !== undefined) {
      resolved.CPT = new Array(msg.CPT.length);
      for (let i = 0; i < resolved.CPT.length; ++i) {
        resolved.CPT[i] = ConditionalProbability.Resolve(msg.CPT[i]);
      }
    }
    else {
      resolved.CPT = []
    }

    return resolved;
    }
};

module.exports = DiscreteNode;
