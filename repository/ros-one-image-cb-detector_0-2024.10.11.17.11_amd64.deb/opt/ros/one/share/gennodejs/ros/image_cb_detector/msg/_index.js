
"use strict";

let ConfigActionFeedback = require('./ConfigActionFeedback.js');
let ConfigActionResult = require('./ConfigActionResult.js');
let ConfigResult = require('./ConfigResult.js');
let ConfigActionGoal = require('./ConfigActionGoal.js');
let ConfigFeedback = require('./ConfigFeedback.js');
let ConfigGoal = require('./ConfigGoal.js');
let ConfigAction = require('./ConfigAction.js');
let ObjectInImage = require('./ObjectInImage.js');
let ImagePoint = require('./ImagePoint.js');

module.exports = {
  ConfigActionFeedback: ConfigActionFeedback,
  ConfigActionResult: ConfigActionResult,
  ConfigResult: ConfigResult,
  ConfigActionGoal: ConfigActionGoal,
  ConfigFeedback: ConfigFeedback,
  ConfigGoal: ConfigGoal,
  ConfigAction: ConfigAction,
  ObjectInImage: ObjectInImage,
  ImagePoint: ImagePoint,
};
