
"use strict";

let PowerBoardCommand = require('./PowerBoardCommand.js')
let PowerBoardCommand2 = require('./PowerBoardCommand2.js')

module.exports = {
  PowerBoardCommand: PowerBoardCommand,
  PowerBoardCommand2: PowerBoardCommand2,
};
