
"use strict";

let AssembleScans = require('./AssembleScans.js')
let AssembleScans2 = require('./AssembleScans2.js')

module.exports = {
  AssembleScans: AssembleScans,
  AssembleScans2: AssembleScans2,
};
