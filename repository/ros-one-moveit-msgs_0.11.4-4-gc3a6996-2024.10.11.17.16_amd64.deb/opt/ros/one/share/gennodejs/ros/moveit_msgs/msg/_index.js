
"use strict";

let MoveGroupFeedback = require('./MoveGroupFeedback.js');
let ExecuteTrajectoryResult = require('./ExecuteTrajectoryResult.js');
let ExecuteTrajectoryFeedback = require('./ExecuteTrajectoryFeedback.js');
let MoveGroupResult = require('./MoveGroupResult.js');
let PlaceResult = require('./PlaceResult.js');
let ExecuteTrajectoryActionGoal = require('./ExecuteTrajectoryActionGoal.js');
let PlaceGoal = require('./PlaceGoal.js');
let MoveGroupSequenceActionGoal = require('./MoveGroupSequenceActionGoal.js');
let PickupAction = require('./PickupAction.js');
let MoveGroupGoal = require('./MoveGroupGoal.js');
let PlaceFeedback = require('./PlaceFeedback.js');
let ExecuteTrajectoryActionResult = require('./ExecuteTrajectoryActionResult.js');
let PickupGoal = require('./PickupGoal.js');
let PickupActionGoal = require('./PickupActionGoal.js');
let MoveGroupActionFeedback = require('./MoveGroupActionFeedback.js');
let MoveGroupSequenceActionResult = require('./MoveGroupSequenceActionResult.js');
let ExecuteTrajectoryAction = require('./ExecuteTrajectoryAction.js');
let MoveGroupSequenceActionFeedback = require('./MoveGroupSequenceActionFeedback.js');
let MoveGroupAction = require('./MoveGroupAction.js');
let PickupActionFeedback = require('./PickupActionFeedback.js');
let PickupResult = require('./PickupResult.js');
let PlaceActionFeedback = require('./PlaceActionFeedback.js');
let PlaceActionResult = require('./PlaceActionResult.js');
let MoveGroupSequenceResult = require('./MoveGroupSequenceResult.js');
let PickupActionResult = require('./PickupActionResult.js');
let ExecuteTrajectoryActionFeedback = require('./ExecuteTrajectoryActionFeedback.js');
let MoveGroupSequenceGoal = require('./MoveGroupSequenceGoal.js');
let PlaceAction = require('./PlaceAction.js');
let ExecuteTrajectoryGoal = require('./ExecuteTrajectoryGoal.js');
let MoveGroupSequenceAction = require('./MoveGroupSequenceAction.js');
let MoveGroupSequenceFeedback = require('./MoveGroupSequenceFeedback.js');
let PickupFeedback = require('./PickupFeedback.js');
let MoveGroupActionResult = require('./MoveGroupActionResult.js');
let PlaceActionGoal = require('./PlaceActionGoal.js');
let MoveGroupActionGoal = require('./MoveGroupActionGoal.js');
let PlanningScene = require('./PlanningScene.js');
let CartesianPoint = require('./CartesianPoint.js');
let Constraints = require('./Constraints.js');
let ConstraintEvalResult = require('./ConstraintEvalResult.js');
let RobotTrajectory = require('./RobotTrajectory.js');
let RobotState = require('./RobotState.js');
let CostSource = require('./CostSource.js');
let PositionIKRequest = require('./PositionIKRequest.js');
let GenericTrajectory = require('./GenericTrajectory.js');
let JointLimits = require('./JointLimits.js');
let PlannerInterfaceDescription = require('./PlannerInterfaceDescription.js');
let PlanningSceneWorld = require('./PlanningSceneWorld.js');
let MotionPlanResponse = require('./MotionPlanResponse.js');
let MotionSequenceResponse = require('./MotionSequenceResponse.js');
let MotionSequenceRequest = require('./MotionSequenceRequest.js');
let MotionPlanRequest = require('./MotionPlanRequest.js');
let LinkScale = require('./LinkScale.js');
let ContactInformation = require('./ContactInformation.js');
let PlanningOptions = require('./PlanningOptions.js');
let BoundingVolume = require('./BoundingVolume.js');
let VisibilityConstraint = require('./VisibilityConstraint.js');
let LinkPadding = require('./LinkPadding.js');
let MotionSequenceItem = require('./MotionSequenceItem.js');
let ObjectColor = require('./ObjectColor.js');
let PlannerParams = require('./PlannerParams.js');
let OrientationConstraint = require('./OrientationConstraint.js');
let PlanningSceneComponents = require('./PlanningSceneComponents.js');
let AttachedCollisionObject = require('./AttachedCollisionObject.js');
let CollisionObject = require('./CollisionObject.js');
let OrientedBoundingBox = require('./OrientedBoundingBox.js');
let MoveItErrorCodes = require('./MoveItErrorCodes.js');
let DisplayRobotState = require('./DisplayRobotState.js');
let DisplayTrajectory = require('./DisplayTrajectory.js');
let Grasp = require('./Grasp.js');
let CartesianTrajectoryPoint = require('./CartesianTrajectoryPoint.js');
let AllowedCollisionEntry = require('./AllowedCollisionEntry.js');
let CartesianTrajectory = require('./CartesianTrajectory.js');
let JointConstraint = require('./JointConstraint.js');
let TrajectoryConstraints = require('./TrajectoryConstraints.js');
let WorkspaceParameters = require('./WorkspaceParameters.js');
let AllowedCollisionMatrix = require('./AllowedCollisionMatrix.js');
let PlaceLocation = require('./PlaceLocation.js');
let GripperTranslation = require('./GripperTranslation.js');
let MotionPlanDetailedResponse = require('./MotionPlanDetailedResponse.js');
let KinematicSolverInfo = require('./KinematicSolverInfo.js');
let PositionConstraint = require('./PositionConstraint.js');

module.exports = {
  MoveGroupFeedback: MoveGroupFeedback,
  ExecuteTrajectoryResult: ExecuteTrajectoryResult,
  ExecuteTrajectoryFeedback: ExecuteTrajectoryFeedback,
  MoveGroupResult: MoveGroupResult,
  PlaceResult: PlaceResult,
  ExecuteTrajectoryActionGoal: ExecuteTrajectoryActionGoal,
  PlaceGoal: PlaceGoal,
  MoveGroupSequenceActionGoal: MoveGroupSequenceActionGoal,
  PickupAction: PickupAction,
  MoveGroupGoal: MoveGroupGoal,
  PlaceFeedback: PlaceFeedback,
  ExecuteTrajectoryActionResult: ExecuteTrajectoryActionResult,
  PickupGoal: PickupGoal,
  PickupActionGoal: PickupActionGoal,
  MoveGroupActionFeedback: MoveGroupActionFeedback,
  MoveGroupSequenceActionResult: MoveGroupSequenceActionResult,
  ExecuteTrajectoryAction: ExecuteTrajectoryAction,
  MoveGroupSequenceActionFeedback: MoveGroupSequenceActionFeedback,
  MoveGroupAction: MoveGroupAction,
  PickupActionFeedback: PickupActionFeedback,
  PickupResult: PickupResult,
  PlaceActionFeedback: PlaceActionFeedback,
  PlaceActionResult: PlaceActionResult,
  MoveGroupSequenceResult: MoveGroupSequenceResult,
  PickupActionResult: PickupActionResult,
  ExecuteTrajectoryActionFeedback: ExecuteTrajectoryActionFeedback,
  MoveGroupSequenceGoal: MoveGroupSequenceGoal,
  PlaceAction: PlaceAction,
  ExecuteTrajectoryGoal: ExecuteTrajectoryGoal,
  MoveGroupSequenceAction: MoveGroupSequenceAction,
  MoveGroupSequenceFeedback: MoveGroupSequenceFeedback,
  PickupFeedback: PickupFeedback,
  MoveGroupActionResult: MoveGroupActionResult,
  PlaceActionGoal: PlaceActionGoal,
  MoveGroupActionGoal: MoveGroupActionGoal,
  PlanningScene: PlanningScene,
  CartesianPoint: CartesianPoint,
  Constraints: Constraints,
  ConstraintEvalResult: ConstraintEvalResult,
  RobotTrajectory: RobotTrajectory,
  RobotState: RobotState,
  CostSource: CostSource,
  PositionIKRequest: PositionIKRequest,
  GenericTrajectory: GenericTrajectory,
  JointLimits: JointLimits,
  PlannerInterfaceDescription: PlannerInterfaceDescription,
  PlanningSceneWorld: PlanningSceneWorld,
  MotionPlanResponse: MotionPlanResponse,
  MotionSequenceResponse: MotionSequenceResponse,
  MotionSequenceRequest: MotionSequenceRequest,
  MotionPlanRequest: MotionPlanRequest,
  LinkScale: LinkScale,
  ContactInformation: ContactInformation,
  PlanningOptions: PlanningOptions,
  BoundingVolume: BoundingVolume,
  VisibilityConstraint: VisibilityConstraint,
  LinkPadding: LinkPadding,
  MotionSequenceItem: MotionSequenceItem,
  ObjectColor: ObjectColor,
  PlannerParams: PlannerParams,
  OrientationConstraint: OrientationConstraint,
  PlanningSceneComponents: PlanningSceneComponents,
  AttachedCollisionObject: AttachedCollisionObject,
  CollisionObject: CollisionObject,
  OrientedBoundingBox: OrientedBoundingBox,
  MoveItErrorCodes: MoveItErrorCodes,
  DisplayRobotState: DisplayRobotState,
  DisplayTrajectory: DisplayTrajectory,
  Grasp: Grasp,
  CartesianTrajectoryPoint: CartesianTrajectoryPoint,
  AllowedCollisionEntry: AllowedCollisionEntry,
  CartesianTrajectory: CartesianTrajectory,
  JointConstraint: JointConstraint,
  TrajectoryConstraints: TrajectoryConstraints,
  WorkspaceParameters: WorkspaceParameters,
  AllowedCollisionMatrix: AllowedCollisionMatrix,
  PlaceLocation: PlaceLocation,
  GripperTranslation: GripperTranslation,
  MotionPlanDetailedResponse: MotionPlanDetailedResponse,
  KinematicSolverInfo: KinematicSolverInfo,
  PositionConstraint: PositionConstraint,
};
