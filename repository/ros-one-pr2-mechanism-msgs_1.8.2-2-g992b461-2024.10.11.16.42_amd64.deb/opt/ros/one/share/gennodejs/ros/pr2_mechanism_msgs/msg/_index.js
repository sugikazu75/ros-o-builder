
"use strict";

let SwitchControllerAction = require('./SwitchControllerAction.js');
let SwitchControllerActionGoal = require('./SwitchControllerActionGoal.js');
let SwitchControllerActionFeedback = require('./SwitchControllerActionFeedback.js');
let SwitchControllerGoal = require('./SwitchControllerGoal.js');
let SwitchControllerFeedback = require('./SwitchControllerFeedback.js');
let SwitchControllerActionResult = require('./SwitchControllerActionResult.js');
let SwitchControllerResult = require('./SwitchControllerResult.js');
let JointStatistics = require('./JointStatistics.js');
let ActuatorStatistics = require('./ActuatorStatistics.js');
let ControllerStatistics = require('./ControllerStatistics.js');
let MechanismStatistics = require('./MechanismStatistics.js');

module.exports = {
  SwitchControllerAction: SwitchControllerAction,
  SwitchControllerActionGoal: SwitchControllerActionGoal,
  SwitchControllerActionFeedback: SwitchControllerActionFeedback,
  SwitchControllerGoal: SwitchControllerGoal,
  SwitchControllerFeedback: SwitchControllerFeedback,
  SwitchControllerActionResult: SwitchControllerActionResult,
  SwitchControllerResult: SwitchControllerResult,
  JointStatistics: JointStatistics,
  ActuatorStatistics: ActuatorStatistics,
  ControllerStatistics: ControllerStatistics,
  MechanismStatistics: MechanismStatistics,
};
