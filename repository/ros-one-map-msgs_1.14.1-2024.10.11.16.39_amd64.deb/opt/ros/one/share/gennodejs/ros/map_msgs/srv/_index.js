
"use strict";

let ProjectedMapsInfo = require('./ProjectedMapsInfo.js')
let GetPointMap = require('./GetPointMap.js')
let GetMapROI = require('./GetMapROI.js')
let GetPointMapROI = require('./GetPointMapROI.js')
let SaveMap = require('./SaveMap.js')
let SetMapProjections = require('./SetMapProjections.js')

module.exports = {
  ProjectedMapsInfo: ProjectedMapsInfo,
  GetPointMap: GetPointMap,
  GetMapROI: GetMapROI,
  GetPointMapROI: GetPointMapROI,
  SaveMap: SaveMap,
  SetMapProjections: SetMapProjections,
};
