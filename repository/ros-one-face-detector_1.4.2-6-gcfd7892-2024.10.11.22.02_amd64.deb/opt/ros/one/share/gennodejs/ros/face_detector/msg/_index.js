
"use strict";

let FaceDetectorAction = require('./FaceDetectorAction.js');
let FaceDetectorFeedback = require('./FaceDetectorFeedback.js');
let FaceDetectorResult = require('./FaceDetectorResult.js');
let FaceDetectorActionResult = require('./FaceDetectorActionResult.js');
let FaceDetectorActionFeedback = require('./FaceDetectorActionFeedback.js');
let FaceDetectorGoal = require('./FaceDetectorGoal.js');
let FaceDetectorActionGoal = require('./FaceDetectorActionGoal.js');

module.exports = {
  FaceDetectorAction: FaceDetectorAction,
  FaceDetectorFeedback: FaceDetectorFeedback,
  FaceDetectorResult: FaceDetectorResult,
  FaceDetectorActionResult: FaceDetectorActionResult,
  FaceDetectorActionFeedback: FaceDetectorActionFeedback,
  FaceDetectorGoal: FaceDetectorGoal,
  FaceDetectorActionGoal: FaceDetectorActionGoal,
};
