
"use strict";

let SetWaveform = require('./SetWaveform.js')
let SetMultiWaveform = require('./SetMultiWaveform.js')

module.exports = {
  SetWaveform: SetWaveform,
  SetMultiWaveform: SetMultiWaveform,
};
