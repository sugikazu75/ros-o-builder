
"use strict";

let StageDescription = require('./StageDescription.js');
let Solution = require('./Solution.js');
let StageStatistics = require('./StageStatistics.js');
let TaskDescription = require('./TaskDescription.js');
let TrajectoryExecutionInfo = require('./TrajectoryExecutionInfo.js');
let Property = require('./Property.js');
let SubSolution = require('./SubSolution.js');
let TaskStatistics = require('./TaskStatistics.js');
let SubTrajectory = require('./SubTrajectory.js');
let SolutionInfo = require('./SolutionInfo.js');
let ExecuteTaskSolutionGoal = require('./ExecuteTaskSolutionGoal.js');
let ExecuteTaskSolutionFeedback = require('./ExecuteTaskSolutionFeedback.js');
let ExecuteTaskSolutionActionResult = require('./ExecuteTaskSolutionActionResult.js');
let ExecuteTaskSolutionAction = require('./ExecuteTaskSolutionAction.js');
let ExecuteTaskSolutionActionFeedback = require('./ExecuteTaskSolutionActionFeedback.js');
let ExecuteTaskSolutionResult = require('./ExecuteTaskSolutionResult.js');
let ExecuteTaskSolutionActionGoal = require('./ExecuteTaskSolutionActionGoal.js');

module.exports = {
  StageDescription: StageDescription,
  Solution: Solution,
  StageStatistics: StageStatistics,
  TaskDescription: TaskDescription,
  TrajectoryExecutionInfo: TrajectoryExecutionInfo,
  Property: Property,
  SubSolution: SubSolution,
  TaskStatistics: TaskStatistics,
  SubTrajectory: SubTrajectory,
  SolutionInfo: SolutionInfo,
  ExecuteTaskSolutionGoal: ExecuteTaskSolutionGoal,
  ExecuteTaskSolutionFeedback: ExecuteTaskSolutionFeedback,
  ExecuteTaskSolutionActionResult: ExecuteTaskSolutionActionResult,
  ExecuteTaskSolutionAction: ExecuteTaskSolutionAction,
  ExecuteTaskSolutionActionFeedback: ExecuteTaskSolutionActionFeedback,
  ExecuteTaskSolutionResult: ExecuteTaskSolutionResult,
  ExecuteTaskSolutionActionGoal: ExecuteTaskSolutionActionGoal,
};
