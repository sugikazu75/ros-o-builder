
"use strict";

let SetParam = require('./SetParam.js')
let MongoUpdate = require('./MongoUpdate.js')
let GetParam = require('./GetParam.js')
let MongoFind = require('./MongoFind.js')
let MongoInsert = require('./MongoInsert.js')

module.exports = {
  SetParam: SetParam,
  MongoUpdate: MongoUpdate,
  GetParam: GetParam,
  MongoFind: MongoFind,
  MongoInsert: MongoInsert,
};
