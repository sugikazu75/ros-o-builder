// Auto-generated. Do not edit!

// (in-package image_view2.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let PointArrayStamped = require('./PointArrayStamped.js');
let std_msgs = _finder('std_msgs');
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class ImageMarker2 {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.ns = null;
      this.id = null;
      this.type = null;
      this.action = null;
      this.position = null;
      this.position3D = null;
      this.pose = null;
      this.scale = null;
      this.width = null;
      this.outline_color = null;
      this.filled = null;
      this.fill_color = null;
      this.lifetime = null;
      this.arc = null;
      this.angle = null;
      this.points = null;
      this.points3D = null;
      this.outline_colors = null;
      this.frames = null;
      this.text = null;
      this.left_up_origin = null;
      this.ratio_scale = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('ns')) {
        this.ns = initObj.ns
      }
      else {
        this.ns = '';
      }
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = 0;
      }
      if (initObj.hasOwnProperty('type')) {
        this.type = initObj.type
      }
      else {
        this.type = 0;
      }
      if (initObj.hasOwnProperty('action')) {
        this.action = initObj.action
      }
      else {
        this.action = 0;
      }
      if (initObj.hasOwnProperty('position')) {
        this.position = initObj.position
      }
      else {
        this.position = new geometry_msgs.msg.Point();
      }
      if (initObj.hasOwnProperty('position3D')) {
        this.position3D = initObj.position3D
      }
      else {
        this.position3D = new geometry_msgs.msg.PointStamped();
      }
      if (initObj.hasOwnProperty('pose')) {
        this.pose = initObj.pose
      }
      else {
        this.pose = new geometry_msgs.msg.PoseStamped();
      }
      if (initObj.hasOwnProperty('scale')) {
        this.scale = initObj.scale
      }
      else {
        this.scale = 0.0;
      }
      if (initObj.hasOwnProperty('width')) {
        this.width = initObj.width
      }
      else {
        this.width = 0.0;
      }
      if (initObj.hasOwnProperty('outline_color')) {
        this.outline_color = initObj.outline_color
      }
      else {
        this.outline_color = new std_msgs.msg.ColorRGBA();
      }
      if (initObj.hasOwnProperty('filled')) {
        this.filled = initObj.filled
      }
      else {
        this.filled = 0;
      }
      if (initObj.hasOwnProperty('fill_color')) {
        this.fill_color = initObj.fill_color
      }
      else {
        this.fill_color = new std_msgs.msg.ColorRGBA();
      }
      if (initObj.hasOwnProperty('lifetime')) {
        this.lifetime = initObj.lifetime
      }
      else {
        this.lifetime = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('arc')) {
        this.arc = initObj.arc
      }
      else {
        this.arc = 0;
      }
      if (initObj.hasOwnProperty('angle')) {
        this.angle = initObj.angle
      }
      else {
        this.angle = 0.0;
      }
      if (initObj.hasOwnProperty('points')) {
        this.points = initObj.points
      }
      else {
        this.points = [];
      }
      if (initObj.hasOwnProperty('points3D')) {
        this.points3D = initObj.points3D
      }
      else {
        this.points3D = new PointArrayStamped();
      }
      if (initObj.hasOwnProperty('outline_colors')) {
        this.outline_colors = initObj.outline_colors
      }
      else {
        this.outline_colors = [];
      }
      if (initObj.hasOwnProperty('frames')) {
        this.frames = initObj.frames
      }
      else {
        this.frames = [];
      }
      if (initObj.hasOwnProperty('text')) {
        this.text = initObj.text
      }
      else {
        this.text = '';
      }
      if (initObj.hasOwnProperty('left_up_origin')) {
        this.left_up_origin = initObj.left_up_origin
      }
      else {
        this.left_up_origin = false;
      }
      if (initObj.hasOwnProperty('ratio_scale')) {
        this.ratio_scale = initObj.ratio_scale
      }
      else {
        this.ratio_scale = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ImageMarker2
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [ns]
    bufferOffset = _serializer.string(obj.ns, buffer, bufferOffset);
    // Serialize message field [id]
    bufferOffset = _serializer.int32(obj.id, buffer, bufferOffset);
    // Serialize message field [type]
    bufferOffset = _serializer.int32(obj.type, buffer, bufferOffset);
    // Serialize message field [action]
    bufferOffset = _serializer.int32(obj.action, buffer, bufferOffset);
    // Serialize message field [position]
    bufferOffset = geometry_msgs.msg.Point.serialize(obj.position, buffer, bufferOffset);
    // Serialize message field [position3D]
    bufferOffset = geometry_msgs.msg.PointStamped.serialize(obj.position3D, buffer, bufferOffset);
    // Serialize message field [pose]
    bufferOffset = geometry_msgs.msg.PoseStamped.serialize(obj.pose, buffer, bufferOffset);
    // Serialize message field [scale]
    bufferOffset = _serializer.float32(obj.scale, buffer, bufferOffset);
    // Serialize message field [width]
    bufferOffset = _serializer.float32(obj.width, buffer, bufferOffset);
    // Serialize message field [outline_color]
    bufferOffset = std_msgs.msg.ColorRGBA.serialize(obj.outline_color, buffer, bufferOffset);
    // Serialize message field [filled]
    bufferOffset = _serializer.byte(obj.filled, buffer, bufferOffset);
    // Serialize message field [fill_color]
    bufferOffset = std_msgs.msg.ColorRGBA.serialize(obj.fill_color, buffer, bufferOffset);
    // Serialize message field [lifetime]
    bufferOffset = _serializer.duration(obj.lifetime, buffer, bufferOffset);
    // Serialize message field [arc]
    bufferOffset = _serializer.byte(obj.arc, buffer, bufferOffset);
    // Serialize message field [angle]
    bufferOffset = _serializer.float32(obj.angle, buffer, bufferOffset);
    // Serialize message field [points]
    // Serialize the length for message field [points]
    bufferOffset = _serializer.uint32(obj.points.length, buffer, bufferOffset);
    obj.points.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Point.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [points3D]
    bufferOffset = PointArrayStamped.serialize(obj.points3D, buffer, bufferOffset);
    // Serialize message field [outline_colors]
    // Serialize the length for message field [outline_colors]
    bufferOffset = _serializer.uint32(obj.outline_colors.length, buffer, bufferOffset);
    obj.outline_colors.forEach((val) => {
      bufferOffset = std_msgs.msg.ColorRGBA.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [frames]
    bufferOffset = _arraySerializer.string(obj.frames, buffer, bufferOffset, null);
    // Serialize message field [text]
    bufferOffset = _serializer.string(obj.text, buffer, bufferOffset);
    // Serialize message field [left_up_origin]
    bufferOffset = _serializer.bool(obj.left_up_origin, buffer, bufferOffset);
    // Serialize message field [ratio_scale]
    bufferOffset = _serializer.bool(obj.ratio_scale, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ImageMarker2
    let len;
    let data = new ImageMarker2(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [ns]
    data.ns = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [id]
    data.id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [type]
    data.type = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [action]
    data.action = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [position]
    data.position = geometry_msgs.msg.Point.deserialize(buffer, bufferOffset);
    // Deserialize message field [position3D]
    data.position3D = geometry_msgs.msg.PointStamped.deserialize(buffer, bufferOffset);
    // Deserialize message field [pose]
    data.pose = geometry_msgs.msg.PoseStamped.deserialize(buffer, bufferOffset);
    // Deserialize message field [scale]
    data.scale = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [width]
    data.width = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [outline_color]
    data.outline_color = std_msgs.msg.ColorRGBA.deserialize(buffer, bufferOffset);
    // Deserialize message field [filled]
    data.filled = _deserializer.byte(buffer, bufferOffset);
    // Deserialize message field [fill_color]
    data.fill_color = std_msgs.msg.ColorRGBA.deserialize(buffer, bufferOffset);
    // Deserialize message field [lifetime]
    data.lifetime = _deserializer.duration(buffer, bufferOffset);
    // Deserialize message field [arc]
    data.arc = _deserializer.byte(buffer, bufferOffset);
    // Deserialize message field [angle]
    data.angle = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [points]
    // Deserialize array length for message field [points]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.points = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.points[i] = geometry_msgs.msg.Point.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [points3D]
    data.points3D = PointArrayStamped.deserialize(buffer, bufferOffset);
    // Deserialize message field [outline_colors]
    // Deserialize array length for message field [outline_colors]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.outline_colors = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.outline_colors[i] = std_msgs.msg.ColorRGBA.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [frames]
    data.frames = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [text]
    data.text = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [left_up_origin]
    data.left_up_origin = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [ratio_scale]
    data.ratio_scale = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += _getByteLength(object.ns);
    length += geometry_msgs.msg.PointStamped.getMessageSize(object.position3D);
    length += geometry_msgs.msg.PoseStamped.getMessageSize(object.pose);
    length += 24 * object.points.length;
    length += PointArrayStamped.getMessageSize(object.points3D);
    length += 16 * object.outline_colors.length;
    object.frames.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    length += _getByteLength(object.text);
    return length + 112;
  }

  static datatype() {
    // Returns string type for a message object
    return 'image_view2/ImageMarker2';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '8efc23e411f94f2c04288719c078c291';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    byte CIRCLE=0
    byte LINE_STRIP=1
    byte LINE_LIST=2
    byte POLYGON=3
    byte POINTS=4
    byte FRAMES=5
    byte TEXT=6
    
    byte LINE_STRIP3D=7
    byte LINE_LIST3D=8
    byte POLYGON3D=9
    byte POINTS3D=10
    byte TEXT3D=11
    byte CIRCLE3D=12
    
    byte ADD=0
    byte REMOVE=1
    
    Header header
    string ns		# namespace, used with id to form a unique id
    int32 id          	# unique id within the namespace
    int32 type        	# CIRCLE/LINE_STRIP/etc.
    int32 action      	# ADD/REMOVE
    geometry_msgs/Point position # used for CIRCLE/TEXT, 2D in pixel-coords
    geometry_msgs/PointStamped position3D # used for 3DTEXT
    geometry_msgs/PoseStamped pose # used for CIRCLE3D
    float32 scale	 	# the diameter for a circle, etc.
    float32 width	 	# the width for a line, etc.
    std_msgs/ColorRGBA outline_color
    byte filled		# whether to fill in the shape with color
    std_msgs/ColorRGBA fill_color # color [0.0-1.0]
    duration lifetime       # How long the object should last before being automatically deleted.  0 means forever
    byte arc # used for CIRCLE3D
    float32 angle # used for CIRCLE3D
    
    
    geometry_msgs/Point[] points # used for LINE_STRIP/LINE_LIST/POLYGON/POINTS., 2D in pixel coords
    PointArrayStamped points3D # used for 3DLINE_STRIP/3DLINE_LIST/3DPOLYGON/3DPOINTS
    std_msgs/ColorRGBA[] outline_colors # a color for each line, point, etc.
    
    string[] frames # used for FRAMES, tf names
    string text             # used for TEXT, draw size of text is scale
    bool left_up_origin     # draw text from left up origin
    bool ratio_scale        #Use ratio respected to original image to specify scale and position
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/PointStamped
    # This represents a Point with reference coordinate frame and timestamp
    Header header
    Point point
    
    ================================================================================
    MSG: geometry_msgs/PoseStamped
    # A Pose with reference coordinate frame and timestamp
    Header header
    Pose pose
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    ================================================================================
    MSG: std_msgs/ColorRGBA
    float32 r
    float32 g
    float32 b
    float32 a
    
    ================================================================================
    MSG: image_view2/PointArrayStamped
    Header header
    
    geometry_msgs/Point[] points
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ImageMarker2(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.ns !== undefined) {
      resolved.ns = msg.ns;
    }
    else {
      resolved.ns = ''
    }

    if (msg.id !== undefined) {
      resolved.id = msg.id;
    }
    else {
      resolved.id = 0
    }

    if (msg.type !== undefined) {
      resolved.type = msg.type;
    }
    else {
      resolved.type = 0
    }

    if (msg.action !== undefined) {
      resolved.action = msg.action;
    }
    else {
      resolved.action = 0
    }

    if (msg.position !== undefined) {
      resolved.position = geometry_msgs.msg.Point.Resolve(msg.position)
    }
    else {
      resolved.position = new geometry_msgs.msg.Point()
    }

    if (msg.position3D !== undefined) {
      resolved.position3D = geometry_msgs.msg.PointStamped.Resolve(msg.position3D)
    }
    else {
      resolved.position3D = new geometry_msgs.msg.PointStamped()
    }

    if (msg.pose !== undefined) {
      resolved.pose = geometry_msgs.msg.PoseStamped.Resolve(msg.pose)
    }
    else {
      resolved.pose = new geometry_msgs.msg.PoseStamped()
    }

    if (msg.scale !== undefined) {
      resolved.scale = msg.scale;
    }
    else {
      resolved.scale = 0.0
    }

    if (msg.width !== undefined) {
      resolved.width = msg.width;
    }
    else {
      resolved.width = 0.0
    }

    if (msg.outline_color !== undefined) {
      resolved.outline_color = std_msgs.msg.ColorRGBA.Resolve(msg.outline_color)
    }
    else {
      resolved.outline_color = new std_msgs.msg.ColorRGBA()
    }

    if (msg.filled !== undefined) {
      resolved.filled = msg.filled;
    }
    else {
      resolved.filled = 0
    }

    if (msg.fill_color !== undefined) {
      resolved.fill_color = std_msgs.msg.ColorRGBA.Resolve(msg.fill_color)
    }
    else {
      resolved.fill_color = new std_msgs.msg.ColorRGBA()
    }

    if (msg.lifetime !== undefined) {
      resolved.lifetime = msg.lifetime;
    }
    else {
      resolved.lifetime = {secs: 0, nsecs: 0}
    }

    if (msg.arc !== undefined) {
      resolved.arc = msg.arc;
    }
    else {
      resolved.arc = 0
    }

    if (msg.angle !== undefined) {
      resolved.angle = msg.angle;
    }
    else {
      resolved.angle = 0.0
    }

    if (msg.points !== undefined) {
      resolved.points = new Array(msg.points.length);
      for (let i = 0; i < resolved.points.length; ++i) {
        resolved.points[i] = geometry_msgs.msg.Point.Resolve(msg.points[i]);
      }
    }
    else {
      resolved.points = []
    }

    if (msg.points3D !== undefined) {
      resolved.points3D = PointArrayStamped.Resolve(msg.points3D)
    }
    else {
      resolved.points3D = new PointArrayStamped()
    }

    if (msg.outline_colors !== undefined) {
      resolved.outline_colors = new Array(msg.outline_colors.length);
      for (let i = 0; i < resolved.outline_colors.length; ++i) {
        resolved.outline_colors[i] = std_msgs.msg.ColorRGBA.Resolve(msg.outline_colors[i]);
      }
    }
    else {
      resolved.outline_colors = []
    }

    if (msg.frames !== undefined) {
      resolved.frames = msg.frames;
    }
    else {
      resolved.frames = []
    }

    if (msg.text !== undefined) {
      resolved.text = msg.text;
    }
    else {
      resolved.text = ''
    }

    if (msg.left_up_origin !== undefined) {
      resolved.left_up_origin = msg.left_up_origin;
    }
    else {
      resolved.left_up_origin = false
    }

    if (msg.ratio_scale !== undefined) {
      resolved.ratio_scale = msg.ratio_scale;
    }
    else {
      resolved.ratio_scale = false
    }

    return resolved;
    }
};

// Constants for message
ImageMarker2.Constants = {
  CIRCLE: 0,
  LINE_STRIP: 1,
  LINE_LIST: 2,
  POLYGON: 3,
  POINTS: 4,
  FRAMES: 5,
  TEXT: 6,
  LINE_STRIP3D: 7,
  LINE_LIST3D: 8,
  POLYGON3D: 9,
  POINTS3D: 10,
  TEXT3D: 11,
  CIRCLE3D: 12,
  ADD: 0,
  REMOVE: 1,
}

module.exports = ImageMarker2;
