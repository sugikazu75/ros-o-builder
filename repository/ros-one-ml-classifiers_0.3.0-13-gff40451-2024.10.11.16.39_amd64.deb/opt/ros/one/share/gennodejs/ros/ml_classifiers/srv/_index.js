
"use strict";

let TrainClassifier = require('./TrainClassifier.js')
let LoadClassifier = require('./LoadClassifier.js')
let ClearClassifier = require('./ClearClassifier.js')
let ClassifyData = require('./ClassifyData.js')
let SaveClassifier = require('./SaveClassifier.js')
let AddClassData = require('./AddClassData.js')
let CreateClassifier = require('./CreateClassifier.js')

module.exports = {
  TrainClassifier: TrainClassifier,
  LoadClassifier: LoadClassifier,
  ClearClassifier: ClearClassifier,
  ClassifyData: ClassifyData,
  SaveClassifier: SaveClassifier,
  AddClassData: AddClassData,
  CreateClassifier: CreateClassifier,
};
